
def FpmlIrd8(tradableProduct, accounts):

    success = None

    return success
