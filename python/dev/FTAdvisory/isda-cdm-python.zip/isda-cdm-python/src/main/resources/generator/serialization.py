from enum import Enum
import json
import datetime
import time
import sys
import os

__all__ = ['deserialize', 'serialize']
def deserializeInsideDict(clase, value):
    object = str_to_class(clase)()
    object = iterateKeys(object, value)

    return(object)


def str_to_class(classname):
    modules = sys.modules[classname+"Test"]
    return getattr(modules, classname)


def serialize(object, filterNulls = False):
    dicto = toDict(object, filterNulls)

    json_object = json.dumps(dicto, indent=4, default=str)

    return json_object

def iterateKeys(object, data):
    for key in data.keys():
        if key == 'meta':
            try:
                if(('schema' in object[key].keys()) or ('location' in object[key].keys())):
                    object = iterateKeys(object, object['value'])
            except:
                pass
        if (key != 'type' and key !='meta'):
            if(type(data[key]) is not dict):
                setattr(object, key, data[key])
            else:
                keyClass = object.__class__.__fields__[key].type_.__name__
                setattr(object, key, deserializeInsideDict(keyClass, data[key]))
    return object




def deserialize(jsonData, className):
    objectData = json.loads(jsonData)

    originalData = objectData

    if ('meta' in objectData.keys()):
        if (('schema' in objectData['meta'].keys()) or ('location' in objectData['meta'].keys())):
            objectData = objectData['value']
    if ('value' in objectData.keys()):
        objectData = objectData['value']
    for key in objectData.keys():
        objectData[key] = iterateSubLevels(objectData[key], originalData)

    object = str_to_class(className)(**objectData)

    return object



def getExternalReference(externalReference, globalReference, data):
    result = None
    try:
        if('meta' in data.keys() and 'value' in data.keys()):
            if('externalKey' in data['meta'].keys() and 'globalKey' in data['meta'].keys()):
                if(externalReference == data['meta']['externalKey'] and  globalReference == data['meta']['globalKey']):
                    return(data['value'])

        for key in data.keys():
            result = getExternalReference(externalReference, globalReference, data[key])
            if(result!=None):
                return result

    except:
        pass



    return None


def iterateSubLevels(data, originalData):
    try:
        if('externalReference' in data.keys() and 'globalReference' in data.keys()):
            value = getExternalReference(data['externalReference'],data['globalReference'], originalData )
            if(value!=None):
                return (value)
        if ('meta' in data.keys()):
            if (('scheme' in data['meta'].keys()) or ('location' in data['meta'].keys())):
                data = data['value']
        if ('value' in data.keys()):
            data = data['value']
    except Exception as ex:
        pass
    if(type(data)==list):
        for i in range(len(data)):
            for key in data[i].keys():
                try:
                    if(type(data[i][key])==list):
                        for j in range(len(data[i][key])):

                            try:
                                ti = time.strptime(data[key][i], '%H:%M:%S')
                                data[key][i] = datetime.time(ti.tm_hour, ti.tm_min, ti.tm_sec)
                            except Exception as ex:
                                pass

                            if('value' in data[i][key][j].keys()):
                                data[i][key][j] = data[i][key][j]['value']

                            data[i][key][j] = iterateSubLevels(data[i][key][j], originalData)
                    else:
                        try:
                            ti = time.strptime(data[key], '%H:%M:%S')
                            data[key] = datetime.time(ti.tm_hour, ti.tm_min, ti.tm_sec)
                        except Exception as ex:
                            pass

                        if ('value' in data[i][key].keys()):
                            data[i][key]= data[i][key]['value']



                        data[i][key] = iterateSubLevels(data[i][key], originalData)
                except Exception as ex:
                    pass
    else:
        try:
            keys = data.keys()
        except:
            return(data)
        for key in data.keys():
            try:
                if (type(data[key]) == list):
                    for i in range(len(data[key])):
                        try:
                            ti = time.strptime(data[key][i], '%H:%M:%S')
                            data[key][i] = datetime.time(ti.tm_hour, ti.tm_min, ti.tm_sec)
                        except Exception as ex:
                            pass

                        if ('value' in data[key][i].keys()):
                            data[key][i] = data[key][i]['value']

                        data[key][i] = iterateSubLevels(data[key][i], originalData)
                else:
                    try:
                        ti = time.strptime(data[key], '%H:%M:%S')
                        data[key] = datetime.time(ti.tm_hour, ti.tm_min, ti.tm_sec)
                    except Exception as ex:
                        pass

                    if ('value' in data[key].keys()):
                        data[key] = data[key]['value']

                    data[key] = iterateSubLevels(data[key], originalData)
            except Exception as ex:
                pass

    return data


def is_primitive(thing):
    primitive = (int, str, bool, datetime.date, datetime.time)
    isPrimitive = type(thing) in primitive
    return  isPrimitive
def toDict(object, filterNulls = False):
    newDict = {}
    try:
        dict = object.__dict__
    except:
        return object
    keys = dict.keys()
    if (isinstance(object, Enum)):
        return(object.value)
    try:
        for a in keys:
            if (is_primitive(dict[a])):
                if(filterNulls==False):
                    newDict[a] = dict[a]
                else:
                    if(dict[a]!=None):
                        newDict[a] = dict[a]
            elif (isinstance(dict[a], Enum)):
                newDict[a] = dict[a].value
            elif (dict[a] == None and filterNulls==False):
                newDict[a] = None
            else:
                if (type(dict[a]) == list):
                    newDict[a] = list()
                    for i in range(len(dict[a])):
                        newDict[a].append(toDict(dict[a][i], filterNulls))
                else:
                    if (filterNulls == False):
                        newDict[a] = toDict(dict[a], filterNulls)
                    else:
                        if (toDict(dict[a]) != None):
                            newDict[a] = toDict(dict[a], filterNulls)

    except KeyError as ex:
        print(ex)

    return newDict

def cleanData(data):
    for key in data.keys():
        if key == 'meta':
            try:
                if (('schema' in object[key].keys()) or ('location' in object[key].keys())):
                    object = iterateKeys(object, object['value'])
            except:
                pass
        if (key != 'type' and key != 'meta'):
            if (type(data[key]) is not dict):
                setattr(object, key, data[key])
            else:
                keyClass = object.__class__.__fields__[key].type_.__name__
                setattr(object, key, deserializeInsideDict(keyClass, data[key]))
    return object



