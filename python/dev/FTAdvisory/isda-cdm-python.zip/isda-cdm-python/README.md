# ISDA CDM Python Implementation

This repository contains both a Python CDM implementation and the code to generate the package from Regnosys' Rosetta specifications.  
 
The Python package can both deserialize CDM into objects and serialize objects with a caveat.  Ingestion of CDM flattens any use of metadata abstraction and, as a result, serialized CDM will not match a source which makes use of metadata objects.

The implementation follows the same approach as those completed for other languages such as C# in that it does not include the complete scope of functionality available in the Java implementation.

The Python package supports CDM version XXX and requires Python ver 3.9+.

The code to create the Python package supports Rosetta version XXX.

## License

It is licensed under XXXX.

## Contributors
- CloudRisk
- TradeHeader SL
- FT Advisory LLC

## Repository Organization

- Root (this README, project configuration files)
  - dist (Python code to read and write CDM, Unit and Functional tests)
  - docker 
  - documentation 
  - src  (Java code to generate Python from Rosetta CDM definitions) 

# Python Package
## Build
The dist directory contains the generated Python code and the build script: 
- build.sh

## Installation, Unit and Functional Tests 

The unit tests in the pytests directory leverage the pytest package to confirm that the implementation successfully supports Rosetta semantics.  Additionally, in the XXX directory there are tests which confirm that certain CDM functionality works as expected.

The dist directory contains the wheel package after build. The following script installs the package and runs tests:
- pytests.sh

The scripts assume access to Python (ver 3.9+).

## Containerized build
The Root directory contains Dockerfile definition to containerize the build, intallation and testing processes of the generated Python code.

Requires generated python code under dist/src
From Root directory:
- Run 'docker build -t <image>:<tag> .'
- Run 'docker run -it <image>:<tag> sh' to enter the container in interactive mode
- Run 'docker run <container_id> <image>:<tag>

## Example

See To demonstrate usage 

An example of how to create a swap ...

# Generation 
## Create new Module
To create your own generator, when accesing to the rosetta-code-generators folder through the cmd, execute the command:

```
mvn archetype:generate -DgroupId="com.regnosys.rosetta.code-generators"  -DartifactId=my-language
```

Afterwards it will ask to fill some parameters. For the moment you can skip all this by pressing enter each time. The new module of your generator will be created and it will be updated the parent ```pom.xml```

## Configure Module

Now that the module of your code generator has been created it's necessary to configure it. Open the ```pom.xml``` of your module and change the following things:

- Inside the tag ```<properties>``` only has to conatin:
  ```<xtend.maven.plugin.version>${xtend.version}</xtend.maven.plugin.version>```
- Inside the tag ```<dependencies>``` only has to contain:
  ```
    <dependency>
      <groupId>com.regnosys.rosetta</groupId>
      <artifactId>com.regnosys.rosetta.lib</artifactId>
    </dependency>
    <dependency>
      <groupId>com.regnosys.rosetta</groupId>
      <artifactId>com.regnosys.rosetta</artifactId>
    </dependency>
    <dependency>
      <groupId>com.regnosys</groupId>
      <artifactId>rosetta-common</artifactId>
    </dependency>
    <dependency>
      <groupId>org.eclipse.emf</groupId>
      <artifactId>org.eclipse.emf.codegen.ecore</artifactId>
    </dependency>
    <dependency>
      <groupId>com.google.guava</groupId>
      <artifactId>guava</artifactId>
    </dependency>
    <dependency>
      <groupId>org.apache.commons</groupId>
      <artifactId>commons-lang3</artifactId>
      <version>${apache.commons.lang.version}</version>
    </dependency>
    <dependency>
      <groupId>org.eclipse.xtend</groupId>
      <artifactId>org.eclipse.xtend.lib</artifactId>
      <version>${xtend.version}</version>
    </dependency>
    <dependency>
      <groupId>org.eclipse.xtext</groupId>
      <artifactId>org.eclipse.xtext</artifactId>
    </dependency>
    <dependency>
      <groupId>com.google.inject</groupId>
      <artifactId>guice</artifactId>
    </dependency>
    
    <dependency>
      <groupId>com.regnosys.rosetta</groupId>
      <artifactId>com.regnosys.rosetta.tests</artifactId>
      <version>${rosetta.dsl.version}</version>
      <scope>test</scope>
    </dependency>
    <dependency>
      <groupId>com.regnosys.rosetta.code-generators</groupId>
      <artifactId>test-helper</artifactId>
      <version>${project.version}</version>
      <scope>test</scope>
    </dependency>
    <dependency>
      <groupId>org.junit.jupiter</groupId>
      <artifactId>junit-jupiter-engine</artifactId>
      <scope>test</scope>
    </dependency>
    <dependency>
      <groupId>org.hamcrest</groupId>
      <artifactId>java-hamcrest</artifactId>
      <scope>test</scope>
    </dependency>
    ```
- And finally inside the tag ```<plugins>```:
  ```
      <plugin>
        <groupId>org.eclipse.xtend</groupId>
        <artifactId>xtend-maven-plugin</artifactId>
        <version>${xtend.maven.plugin.version}</version>
        <executions>
          <execution>
            <id>Generate xtend sources</id>
            <phase>generate-sources</phase>
            <goals>
              <goal>compile</goal>
            </goals>
            <configuration>
              <outputDirectory>${project.basedir}/target/main/generated/xtend</outputDirectory>
            </configuration>
          </execution>
          
          <execution>
            <id>Generate xtend test sources</id>
            <phase>generate-test-sources</phase>
            <goals>
              <goal>testCompile</goal>
            </goals>
            <configuration>
              <testOutputDirectory>${project.basedir}/target/test/generated/xtend</testOutputDirectory>
            </configuration>
          </execution>
          
        </executions>
      </plugin>
  ```
Afterwards your pom will be configured.

## Testing Generator
After your generator code is complete and you want to test your code, you have to use JUnit Test located in the test folder of your module. After executing the command line:
```
mvn clean install
```
It will compile your generator code and your test code and then execute all the tests.
