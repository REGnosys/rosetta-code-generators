version = (0, 0, 0, 1, 'demo')
version_str = '0.0.0-1-demo'
__version__ = '0.0.0.post1.demo'

# EOF
