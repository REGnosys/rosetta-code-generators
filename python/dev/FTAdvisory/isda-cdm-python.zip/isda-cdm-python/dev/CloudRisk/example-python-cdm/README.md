### Example CDM Python code

---

To run the tests or experiment with the examples, please run the **once**
 ```init.bat``` in order to create the virtual environment and install all
 required packages.


 After the initialisation, please activate the python environment with:
 ```DOS
 C:\...\rosetta-code-generators\python\example-python-cdm> .pyenv\Scripts\activate.bat
 ```