version = (3,3,2,0,'g4cc81f0')
version_str = '3,3,2-0-g4cc81f0'
__version__ = '3.3.2'
__build_time__ = '2023-04-05T14:47:48.7951482'