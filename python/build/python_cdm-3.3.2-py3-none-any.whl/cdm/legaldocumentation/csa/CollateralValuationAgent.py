from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CollateralValuationAgent']


class CollateralValuationAgent(BaseDataClass):
    """
    A class to specify Collateral Valuation Agent terms.
    """
    partyElection: Optional[List[CollateralValuationAgentElection]] = Field(None, description="The parties Collateral Valuation Agent Elections.")
    """
          The parties Collateral Valuation Agent Elections.
    """
    @cdm_condition
    def cardinality_partyElection(self):
        return check_cardinality(self.partyElection, 0, 2)


from cdm.legaldocumentation.csa.CollateralValuationAgentElection import CollateralValuationAgentElection

CollateralValuationAgent.update_forward_refs()
