from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['ControlAgreement']


class ControlAgreement(BaseDataClass):
    """
    A class to specify the relationship between the Control Agreement and the Credit Support Agreement.
    """
    partyElection: List[ControlAgreementElections] = Field(None, description="The party specific elections.")
    """
          The party specific elections.
    """
    @cdm_condition
    def cardinality_partyElection(self):
        return check_cardinality(self.partyElection, 2, 2)


from cdm.legaldocumentation.csa.ControlAgreementElections import ControlAgreementElections

ControlAgreement.update_forward_refs()
