from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['SubstitutedRegime']

from cdm.legaldocumentation.csa.RegulatoryRegimeEnum import RegulatoryRegimeEnum

class SubstitutedRegime(BaseDataClass):
    """
    A class to specify each party's election with respect to the Substituted Regimes that will be applicable...
    """
    additionalRegime: Optional[str] = Field(None, description="The additional regulatory regime as specified by the parties.")
    """
          The additional regulatory regime as specified by the parties.
    """
    regime: Optional[RegulatoryRegimeEnum] = Field(None, description="The applicable regulatory regime, as specified through an enumeration.")
    """
          The applicable regulatory regime, as specified through an enumeration.
    """
    regimeTerms: List[SubstitutedRegimeTerms] = Field(None, description="Specifies the applicability of the Substituted Regime as denoted in the Substituted Regime Table as part of certain legal agreements, such as such as the ISDA 2016 and 2018 CSA for Initial Margin.")
    """
          Specifies the applicability of the Substituted Regime as denoted in the Substituted Regime Table as part of certain legal agreements, such as such as the ISDA 2016 and 2018 CSA for Initial Margin.
    """
    @cdm_condition
    def cardinality_regimeTerms(self):
        return check_cardinality(self.regimeTerms, 2, 2)


    @cdm_condition
    def condition_0_SubstitutedRegimeChoice(self):
        """
        The applicable regime should be specified either as an enumeration or as an additional regime specified by the parties.
        """
        return self.check_one_of_constraint('regime', 'additionalRegime', necessity=True)

from cdm.legaldocumentation.csa.SubstitutedRegimeTerms import SubstitutedRegimeTerms

SubstitutedRegime.update_forward_refs()
