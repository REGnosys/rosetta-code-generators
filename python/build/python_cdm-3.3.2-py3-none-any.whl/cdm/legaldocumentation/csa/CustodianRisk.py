from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CustodianRisk']


class CustodianRisk(BaseDataClass):
    """
    A class to specify the Custodian Risk elections specific to a Credit Support Agreement.
    """
    partyElection: List[CustodianRiskElection] = Field(None, description="The party specific elections.")
    """
          The party specific elections.
    """
    @cdm_condition
    def cardinality_partyElection(self):
        return check_cardinality(self.partyElection, 1, 2)


from cdm.legaldocumentation.csa.CustodianRiskElection import CustodianRiskElection

CustodianRisk.update_forward_refs()
