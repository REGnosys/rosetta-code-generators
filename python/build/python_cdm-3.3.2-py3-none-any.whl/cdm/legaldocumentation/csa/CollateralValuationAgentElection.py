from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CollateralValuationAgentElection']

from cdm.base.staticdata.party.CounterpartyRoleEnum import CounterpartyRoleEnum

class CollateralValuationAgentElection(BaseDataClass):
    """
    A class to specify Collateral Valuation Agent language.
    """
    additionalLanguage: Optional[str] = Field(None, description="The additional language that might be specified by the parties to the legal agreement.")
    """
          The additional language that might be specified by the parties to the legal agreement.
    """
    party: CounterpartyRoleEnum = Field(..., description="The elective party.")
    """
          The elective party.
    """


CollateralValuationAgentElection.update_forward_refs()
