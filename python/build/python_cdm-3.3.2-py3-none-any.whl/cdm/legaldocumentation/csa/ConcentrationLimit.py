from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['ConcentrationLimit']


class ConcentrationLimit(BaseDataClass):
    """
    Represents a class to describe concentration limits that may be applicable to eligible collateral criteria.
    """
    concentrationLimitCriteria: Optional[List[ConcentrationLimitCriteria]] = Field(None, description="Specifies a set of criteria to describe the assets that the concentration limits apply to.")
    """
          Specifies a set of criteria to describe the assets that the concentration limits apply to.
    """
    percentageLimit: Optional[NumberRange] = Field(None, description="Specifies the perecentage of collateral limit represented as a decimal number - example 25% is 0.25.")
    """
          Specifies the perecentage of collateral limit represented as a decimal number - example 25% is 0.25.
    """
    valueLimit: Optional[MoneyRange] = Field(None, description="Specifies the value of collateral limit represented as a range.")
    """
          Specifies the value of collateral limit represented as a range.
    """

    @cdm_condition
    def condition_0_ConcentrationLimitValueChoice(self):
        """
        Either a value or percentage concentration limit must be specified.
        """
        return self.check_one_of_constraint('valueLimit', 'percentageLimit', necessity=True)

    @cdm_condition
    def condition_1_PercentageConcentrationLimit(self):
        """
        concentration limit must be described as a percentage.
        """
        return if_cond(all_elements((self.concentrationLimitCriteria.concentrationLimitType), "=", ConcentrationLimitTypeEnum.MarketCapitalisation), '((self.percentageLimit) is not None)', 'True', self)

from cdm.legaldocumentation.csa.ConcentrationLimitCriteria import ConcentrationLimitCriteria
from cdm.base.math.NumberRange import NumberRange
from cdm.base.math.MoneyRange import MoneyRange
from cdm.legaldocumentation.csa.ConcentrationLimitTypeEnum import ConcentrationLimitTypeEnum

ConcentrationLimit.update_forward_refs()
