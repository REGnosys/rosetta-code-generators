from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['FrenchLawAddendum']


class FrenchLawAddendum(BaseDataClass):
    """
    A class to specify party specific elections when a Collateral Transfer Agreement is governed by French Law.
    """
    isApplicable: bool = Field(..., description="The qualification of whether the French Law Addendum is deemed applicable by the parties (True) or not (False).")
    """
          The qualification of whether the French Law Addendum is deemed applicable by the parties (True) or not (False).
    """
    partyElection: Optional[List[FrenchLawAddendumElection]] = Field(None, description="The parties French Law Addendum Elections.")
    """
          The parties French Law Addendum Elections.
    """
    @cdm_condition
    def cardinality_partyElection(self):
        return check_cardinality(self.partyElection, 0, 2)


    @cdm_condition
    def condition_0_Applicable(self):
        """
        A data rule to enforce that the French Law Addendum party elections must be specified when applicable.
        """
        return if_cond(all_elements(self.isApplicable, "=", False), 'all_elements(len(self.partyElection), "=", 2)', 'True', self)

from cdm.legaldocumentation.csa.FrenchLawAddendumElection import FrenchLawAddendumElection

FrenchLawAddendum.update_forward_refs()
