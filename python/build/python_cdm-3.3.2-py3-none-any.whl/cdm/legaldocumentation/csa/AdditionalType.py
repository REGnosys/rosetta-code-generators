from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['AdditionalType']

from cdm.legaldocumentation.csa.AdditionalTypeEnum import AdditionalTypeEnum

class AdditionalType(BaseDataClass):
    """
    The specification of the Additional Type of transaction that can require the collection or delivery of initial margin under a given regulatory regime for the purposes of Covered Transactions, as specified in ISDA 2016 Credit Support Annex for Initial Margin, paragraph 13, General Principles, (b)(B).
    """
    customValue: Optional[str] = Field(None, description="The qualification of the Additional Type of transaction that can require the collection or delivery of initial margin when specified as a custom value by the parties to the legal agreement.")
    """
          The qualification of the Additional Type of transaction that can require the collection or delivery of initial margin when specified as a custom value by the parties to the legal agreement.
    """
    standardValue: AdditionalTypeEnum = Field(..., description="The qualification of the Additional Type of transaction that can require the collection or delivery of initial margin when specified as a standard value.")
    """
          The qualification of the Additional Type of transaction that can require the collection or delivery of initial margin when specified as a standard value.
    """

    @cdm_condition
    def condition_0_CustomValue(self):
        """
        The specification of a custom value by the parties to the legal agreement takes place alongside the qualification of the `Other` value as part of the AdditionalTypeEnum.
        """
        return if_cond(all_elements(self.standardValue, "=", AdditionalTypeEnum.Other), '((self.customValue) is not None)', 'True', self)

    @cdm_condition
    def condition_1_StandardValue(self):
        """
        The specification of a standard value by the parties to the legal agreement is done through the qualification of a value distinct than `Other` as part of the AdditionalTypeEnum, and implies that the customerValue is not being qualified.
        """
        return if_cond(any_elements(self.standardValue, "<>", AdditionalTypeEnum.Other), '((self.customValue) is None)', 'True', self)

from cdm.legaldocumentation.csa.AdditionalTypeEnum import AdditionalTypeEnum

AdditionalType.update_forward_refs()
