from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['AverageTradingVolumeMethodologyEnum']

from enum import Enum

class AverageTradingVolumeMethodologyEnum(Enum):
    """
    Indicates the type of equity average trading volume (single) the highest amount on one exchange, or (consolidated) volumes across more than one exchange.
    """
    CONSOLIDATED = "CONSOLIDATED"
    """
    Consolidated volume across more than one exchange.
    """
    SINGLE = "SINGLE"
    """
    Single, the highest amount on one exchange.
    """
