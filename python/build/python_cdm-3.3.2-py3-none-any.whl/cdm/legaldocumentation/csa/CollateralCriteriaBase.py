from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CollateralCriteriaBase']


class CollateralCriteriaBase(BaseDataClass):
    """
    Represents a set of criteria used to specify and desribe collateral.
    """
    asset: Optional[List[AssetCriteria]] = Field(None, description="Represents a filter based on the criteria realted to the asset.")
    """
          Represents a filter based on the criteria realted to the asset.
    """
    issuer: Optional[List[IssuerCriteria]] = Field(None, description="Represents a filter based criterai related to the issuer.")
    """
          Represents a filter based criterai related to the issuer.
    """

from cdm.legaldocumentation.csa.AssetCriteria import AssetCriteria
from cdm.legaldocumentation.csa.IssuerCriteria import IssuerCriteria

CollateralCriteriaBase.update_forward_refs()
