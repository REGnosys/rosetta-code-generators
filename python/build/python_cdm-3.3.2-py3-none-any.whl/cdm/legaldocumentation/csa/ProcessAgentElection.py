from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['ProcessAgentElection']

from cdm.base.staticdata.party.CounterpartyRoleEnum import CounterpartyRoleEnum

class ProcessAgentElection(BaseDataClass):
    """
    A class to specify the parties' respective elections with respect to the Process Agent.
    """
    isApplicable: bool = Field(..., description="The qualification of whether the Process Agent is applicable (True) or not applicable (False).")
    """
          The qualification of whether the Process Agent is applicable (True) or not applicable (False).
    """
    party: CounterpartyRoleEnum = Field(..., description="The elective party.")
    """
          The elective party.
    """
    processAgent: Optional[PartyContactInformation] = Field(None, description="The Process Agent specification, when applicable.")
    """
          The Process Agent specification, when applicable.
    """

    @cdm_condition
    def condition_0_Applicable(self):
        """
        A data rule to enforce that the Process Agent must be specified when it is applicable.
        """
        return if_cond(all_elements(self.isApplicable, "=", False), '((self.processAgent) is not None)', 'True', self)

    @cdm_condition
    def condition_1_NotApplicable(self):
        """
        A data rule to enforce that the Process Agent cannot be specified if deemed not applicable.
        """
        return if_cond(all_elements(self.isApplicable, "=", False), '((self.processAgent) is None)', 'True', self)

from cdm.base.staticdata.party.PartyContactInformation import PartyContactInformation

ProcessAgentElection.update_forward_refs()
