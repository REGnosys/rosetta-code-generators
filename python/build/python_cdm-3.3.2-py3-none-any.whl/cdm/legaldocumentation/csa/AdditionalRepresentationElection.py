from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['AdditionalRepresentationElection']

from cdm.base.staticdata.party.CounterpartyRoleEnum import CounterpartyRoleEnum

class AdditionalRepresentationElection(BaseDataClass):
    """
    A class to specify the parties' Additional Representation(s) election.
    """
    isApplicable: bool = Field(..., description="The Additional Representation is applicable when True, and not applicable when False.")
    """
          The Additional Representation is applicable when True, and not applicable when False.
    """
    party: CounterpartyRoleEnum = Field(..., description="The elective party.")
    """
          The elective party.
    """


AdditionalRepresentationElection.update_forward_refs()
