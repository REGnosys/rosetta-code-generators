from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['ContactElection']


class ContactElection(BaseDataClass):
    """
    A class to specify the parties' election to specify contact information, in relation to elections such as the Addresses for Transfer or the Demand and Notices as specified in the ISDA Credit Support Annex agreement.
    """
    partyElection: List[PartyContactInformation] = Field(None, description="The parties' contact information election.")
    """
          The parties' contact information election.
    """
    @cdm_condition
    def cardinality_partyElection(self):
        return check_cardinality(self.partyElection, 2, 2)


from cdm.base.staticdata.party.PartyContactInformation import PartyContactInformation

ContactElection.update_forward_refs()
