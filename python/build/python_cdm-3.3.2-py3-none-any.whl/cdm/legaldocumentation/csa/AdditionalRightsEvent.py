from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['AdditionalRightsEvent']


class AdditionalRightsEvent(BaseDataClass):
    """
    A class to specify the Pledgor/Obligor/Chargor Additional Rights Event election. ISDA 2016 English Law Credit Support Deed for Initial Margin, paragraph 13, General Principles, (k): Chargor Additional Rights Event. | ISDA 2016 Japanese Law Credit Support Annex for Initial Margin, paragraph 13, General Principles, (k): Obligor Additional Rights Event. | ISDA 2016 New York Law Credit Support Annex for Initial Margin, paragraph 13, General Principles, (k): Pledgor Additional Rights Event.
    """
    isApplicable: bool = Field(..., description="The Pledgor Additional Rights Event election is applicable when True, and not applicable when False.")
    """
          The Pledgor Additional Rights Event election is applicable when True, and not applicable when False.
    """
    qualification: Optional[str] = Field(None, description="The qualification of the Pledgor Additional Rights Event election, when specified.")
    """
          The qualification of the Pledgor Additional Rights Event election, when specified.
    """

    @cdm_condition
    def condition_0_Qualification(self):
        """
        The Pledgor/Obligor/Chargor Additional Rights should be qualified only when the Pledgor Additional Rights Event election is specified as applicable.
        """
        return if_cond(((self.qualification) is not None), 'all_elements(self.isApplicable, "=", False)', 'True', self)


AdditionalRightsEvent.update_forward_refs()
