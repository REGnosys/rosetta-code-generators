from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['PostingObligationsElection']

from cdm.base.staticdata.party.CounterpartyRoleEnum import CounterpartyRoleEnum

class PostingObligationsElection(BaseDataClass):
    """
    A class to specify the collateral posting obligations for the security provider party(ies), for example, as specified under the terms of the ISDA 2016 Credit Support Annex for Initial Margin, paragraph 13, General Principles, (ii).
    """
    additionalLanguage: Optional[str] = Field(None, description="The additional language that might be specified by the parties to the legal agreement.")
    """
          The additional language that might be specified by the parties to the legal agreement.
    """
    asPermitted: bool = Field(..., description="If set to True, the Control Agreement is a Credit Support Document with respect to the party(ies). ISDA 2016 Credit Support Annex for Initial Margin, paragraph 6, (e).")
    """
          If set to True, the Control Agreement is a Credit Support Document with respect to the party(ies). ISDA 2016 Credit Support Annex for Initial Margin, paragraph 6, (e).
    """
    eligibleCollateral: Optional[List[EligibleCollateralSchedule]] = Field(None, description="The eligible collateral as specified in relation to the pledgor/chargor/obligor(s) posting obligation. ISDA 2016 Credit Support Annex for Initial Margin, Eligible Credit Support (IM) Schedule.")
    """
          The eligible collateral as specified in relation to the pledgor/chargor/obligor(s) posting obligation. ISDA 2016 Credit Support Annex for Initial Margin, Eligible Credit Support (IM) Schedule.
    """
    excludedCollateral: Optional[str] = Field(None, description="The excluded collateral as specified in relation to the pledgor/chargor/obligor(s) posting obligation. ISDA 2016 Credit Support Annex for Initial Margin, paragraph 13, General Principles, (ii)(B)(i).")
    """
          The excluded collateral as specified in relation to the pledgor/chargor/obligor(s) posting obligation. ISDA 2016 Credit Support Annex for Initial Margin, paragraph 13, General Principles, (ii)(B)(i).
    """
    party: CounterpartyRoleEnum = Field(..., description="The elective party.")
    """
          The elective party.
    """

    @cdm_condition
    def condition_0_AsPermitted(self):
        """
        A data rule to enforce that the eligible collateral should be specified when the Control Agreement is a Credit Support Document with respect to the party(ies).
        """
        return if_cond(all_elements(self.asPermitted, "=", False), '((self.eligibleCollateral) is None)', 'True', self)

    @cdm_condition
    def condition_1_EligibleCollateral(self):
        """
        A data rule to enforce that the eligible collateral shouldn't be specified when the Control Agreement isn't deemed a Credit Support Document with respect to the party(ies).
        """
        return if_cond(all_elements(self.asPermitted, "=", False), '((self.eligibleCollateral) is not None)', 'True', self)

from cdm.legaldocumentation.csa.EligibleCollateralSchedule import EligibleCollateralSchedule

PostingObligationsElection.update_forward_refs()
