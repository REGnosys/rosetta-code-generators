from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CollateralAccessBreach']


class CollateralAccessBreach(BaseDataClass):
    """
    A class to specify Collateral Access Breach language
    """
    cabEndDate: Optional[float] = Field(None, description="The business days following the related Collateral Access Breach when the additional terms end ")
    """
          The business days following the related Collateral Access Breach when the additional terms end 
    """
    cabEndDateElection: Optional[bool] = Field(None, description="Determination of whether the Collateral Access Breach end date is a number of days (True) or specified (False)")
    """
          Determination of whether the Collateral Access Breach end date is a number of days (True) or specified (False)
    """
    cabEndDateTerms: Optional[str] = Field(None, description="Specific terms for when Collateral Access Breach terms end")
    """
          Specific terms for when Collateral Access Breach terms end
    """
    isApplicable: bool = Field(..., description="Collateral Access Breach terms are applicable when True and not applicable when False")
    """
          Collateral Access Breach terms are applicable when True and not applicable when False
    """

    @cdm_condition
    def condition_0_CabEndDateTerms(self):
        """
        A condition to require Collateral Access Breach End Date Terms when a specification is required
        """
        return if_cond(all_elements(self.cabEndDateElection, "=", False), '((self.cabEndDateTerms) is None)', 'True', self)


CollateralAccessBreach.update_forward_refs()
