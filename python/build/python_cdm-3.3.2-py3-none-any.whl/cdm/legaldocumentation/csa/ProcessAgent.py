from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['ProcessAgent']


class ProcessAgent(BaseDataClass):
    """
    A class to specify the Process Agent that might be appointed by the parties as part of a Credit Support Annex/Deed or Collateral Transfer Agreement.
    """
    partyElection: List[ProcessAgentElection] = Field(None, description="The parties' Process Agent election.")
    """
          The parties' Process Agent election.
    """
    @cdm_condition
    def cardinality_partyElection(self):
        return check_cardinality(self.partyElection, 2, 2)


from cdm.legaldocumentation.csa.ProcessAgentElection import ProcessAgentElection

ProcessAgent.update_forward_refs()
