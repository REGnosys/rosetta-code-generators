from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CalculationAgentTerms']

from cdm.base.staticdata.party.CounterpartyRoleEnum import CounterpartyRoleEnum

class CalculationAgentTerms(BaseDataClass):
    """
    A class to specify Calculation Agent for purposes of Initial or Variation Margin agreements
    """
    bespokeCalculationAgentTerms: Optional[str] = Field(None, description="The Calculation Agent (IM) terms when specified")
    """
          The Calculation Agent (IM) terms when specified
    """
    party: Optional[List[CounterpartyRoleEnum]] = Field(None, description="The party which is specified as Calculation Agent for Initial Margin.")
    """
          The party which is specified as Calculation Agent for Initial Margin.
    """
    @cdm_condition
    def cardinality_party(self):
        return check_cardinality(self.party, 0, 2)


    @cdm_condition
    def condition_0_(self):
        return self.check_one_of_constraint('party', 'bespokeCalculationAgentTerms', necessity=True)


CalculationAgentTerms.update_forward_refs()
