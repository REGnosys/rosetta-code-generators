from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CoveredTransactions']


class CoveredTransactions(BaseDataClass):
    """
    Specification of Transactions covered by the legal agreement.
    """
    additionalObligations: Optional[List[AdditionalObligations]] = Field(None, description="The party specific additional obligations applicable to the document.")
    """
          The party specific additional obligations applicable to the document.
    """
    @cdm_condition
    def cardinality_additionalObligations(self):
        return check_cardinality(self.additionalObligations, 0, 2)

    bespokeCoveredTransactions: List[str] = Field(None, description="Covered Transactions when not expressed using the ISDA taxonomy.")
    """
          Covered Transactions when not expressed using the ISDA taxonomy.
    """
    @cdm_condition
    def cardinality_bespokeCoveredTransactions(self):
        return check_cardinality(self.bespokeCoveredTransactions, 1, None)

    coveredTransactions: List[ProductTaxonomy] = Field(None, description="Covered Transactions when expressed using the ISDA taxonomy.")
    """
          Covered Transactions when expressed using the ISDA taxonomy.
    """
    @cdm_condition
    def cardinality_coveredTransactions(self):
        return check_cardinality(self.coveredTransactions, 1, None)

    exposure: Optional[str] = Field(None, description="The bespoke definition of exposure for Covered Transactions as part of the agreement.")
    """
          The bespoke definition of exposure for Covered Transactions as part of the agreement.
    """
    inclusionDate: date = Field(..., description="Includes any Transaction specified below that is entered into on or after the specified date.")
    """
          Includes any Transaction specified below that is entered into on or after the specified date.
    """

from cdm.legaldocumentation.csa.AdditionalObligations import AdditionalObligations
from cdm.base.staticdata.asset.common.ProductTaxonomy import ProductTaxonomy

CoveredTransactions.update_forward_refs()
