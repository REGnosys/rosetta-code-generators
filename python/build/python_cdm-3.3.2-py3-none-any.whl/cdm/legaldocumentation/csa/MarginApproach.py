from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['MarginApproach']

from cdm.legaldocumentation.csa.MarginApproachEnum import MarginApproachEnum

class MarginApproach(BaseDataClass):
    """
    A class for selection of Margin Approach.
    """
    marginApproach: MarginApproachEnum = Field(..., description="")


MarginApproach.update_forward_refs()
