from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['AdditionalObligations']

from cdm.base.staticdata.party.CounterpartyRoleEnum import CounterpartyRoleEnum

class AdditionalObligations(BaseDataClass):
    """
    The election of party specific additional obligations applicable to the agreement.
    """
    additionalObligations: str = Field(..., description="The party specific additional obligations applicable to the agreement.")
    """
          The party specific additional obligations applicable to the agreement.
    """
    party: CounterpartyRoleEnum = Field(..., description="The party that the additional obligations apply to.")
    """
          The party that the additional obligations apply to.
    """


AdditionalObligations.update_forward_refs()
