from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['ElectiveAmountElection']

from cdm.legaldocumentation.csa.ElectiveAmountEnum import ElectiveAmountEnum
from cdm.base.staticdata.party.CounterpartyRoleEnum import CounterpartyRoleEnum

class ElectiveAmountElection(BaseDataClass):
    """
    A class to specify the party elective amounts which can be used for the purpose of specifying elections such as the ISDA CSA Threshold and Minimum Transfer Amount.
    """
    amount: Optional[Money] = Field(None, description="The elective amount when expressed as a currency amount. The associated PartyElectiveAmount_amount data rule enforces that the currency amount is actually greater than 0.")
    """
          The elective amount when expressed as a currency amount. The associated PartyElectiveAmount_amount data rule enforces that the currency amount is actually greater than 0.
    """
    customElection: Optional[str] = Field(None, description="The elective amount when expressed as a custom election by the party.")
    """
          The elective amount when expressed as a custom election by the party.
    """
    electiveAmount: Optional[ElectiveAmountEnum] = Field(None, description="Specifies an enumerated election to express the elective amount.")
    """
          Specifies an enumerated election to express the elective amount.
    """
    party: CounterpartyRoleEnum = Field(..., description="The elective party.")
    """
          The elective party.
    """

    @cdm_condition
    def condition_0_NonZeroAmount(self):
        """
        When the elective amount is not zero either a currency amount or a custom election must exist.
        """
        return if_cond(((self.electiveAmount) is None), '(((self.amount) is not None) or ((self.customElection) is not None))', 'True', self)

from cdm.observable.asset.Money import Money

ElectiveAmountElection.update_forward_refs()
