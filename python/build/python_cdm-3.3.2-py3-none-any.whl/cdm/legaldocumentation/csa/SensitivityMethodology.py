from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['SensitivityMethodology']

from cdm.legaldocumentation.csa.SensitivitiesEnum import SensitivitiesEnum

class SensitivityMethodology(BaseDataClass):
    """
    A class to specify the methodology according to which sensitivities to (i) equity indices, funds and ETFs, and (ii) commodity indices are computed. This specification is done either through a normalized election as part of the specifiedMethodology, or through a custom election via the customMethodology attribute. ISDA 2016 Credit Support Annex for Initial Margin, paragraph 13, General Principles, (gg)(2).
    """
    customMethodology: Optional[str] = Field(None, description="The methodology according to which sensitivities will be computed, when specified through a custom election.")
    """
          The methodology according to which sensitivities will be computed, when specified through a custom election.
    """
    specifiedMethodology: Optional[SensitivitiesEnum] = Field(None, description="The methodology according to which sensitivities will be computed, when specified through a normalized election.")
    """
          The methodology according to which sensitivities will be computed, when specified through a normalized election.
    """

    @cdm_condition
    def condition_0_(self):
        return self.check_one_of_constraint('specifiedMethodology', 'customMethodology', necessity=True)


SensitivityMethodology.update_forward_refs()
