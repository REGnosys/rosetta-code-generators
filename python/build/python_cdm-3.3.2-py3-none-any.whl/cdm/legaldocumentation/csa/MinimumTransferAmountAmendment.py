from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['MinimumTransferAmountAmendment']


class MinimumTransferAmountAmendment(BaseDataClass):
    """
     A class to specify whether Amendment to Minimum Transfer Amount language is applicable or not
    """
    effectiveDate: Optional[AmendmentEffectiveDate] = Field(None, description="The effective date of the Amendment to Termination Currency.")
    """
          The effective date of the Amendment to Termination Currency.
    """
    isApplicable: bool = Field(..., description="The definition of Minimum Transfer Amount in any Other Regulatory CSA will be amended when applicable.")
    """
          The definition of Minimum Transfer Amount in any Other Regulatory CSA will be amended when applicable.
    """
    partyElections: Optional[List[ElectiveAmountElection]] = Field(None, description="The party elective amounts.")
    """
          The party elective amounts.
    """
    @cdm_condition
    def cardinality_partyElections(self):
        return check_cardinality(self.partyElections, 0, 2)


    @cdm_condition
    def condition_0_AmendmentNotApplicable(self):
        """
        A data rule to enforce that the Effective Date and Party Elections should be absent when the Minimum Transfer Amount Amendment is stated as not specified for the                       agreement.
        """
        return if_cond(all_elements(self.isApplicable, "=", False), '(((self.effectiveDate) is None) and ((self.partyElections) is None))', 'True', self)

from cdm.legaldocumentation.csa.AmendmentEffectiveDate import AmendmentEffectiveDate
from cdm.legaldocumentation.csa.ElectiveAmountElection import ElectiveAmountElection

MinimumTransferAmountAmendment.update_forward_refs()
