from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CollateralManagementAgreement']


class CollateralManagementAgreement(BaseDataClass):
    """
    A class to specify the Collateral Management Agreement election by the respective parties to a Japanese Law ISDA CSA. ISDA 2016 Japanese Law Credit Support Annex for Initial Margin, paragraph 13, General Principles, (b)(i): Collateral Management Agreement.
    """
    partyElection: List[CollateralManagementAgreementElection] = Field(None, description="The parties' Collateral Management Agreement election.")
    """
          The parties' Collateral Management Agreement election.
    """
    @cdm_condition
    def cardinality_partyElection(self):
        return check_cardinality(self.partyElection, 2, 2)


from cdm.legaldocumentation.csa.CollateralManagementAgreementElection import CollateralManagementAgreementElection

CollateralManagementAgreement.update_forward_refs()
