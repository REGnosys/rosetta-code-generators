from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['BespokeCalculationTime']


class BespokeCalculationTime(BaseDataClass):
    """
    A class to specify additional Calculation Time terms for the purposes of Initial Margin
    """
    asCalculationAgent: bool = Field(..., description="If set to True, the Calculation Time for Initial Margin is the time as of which the Calculation Agent (IM) computes its end of day valuations of derivatives transactions")
    """
          If set to True, the Calculation Time for Initial Margin is the time as of which the Calculation Agent (IM) computes its end of day valuations of derivatives transactions
    """
    bespokeCalculationTimeTerms: Optional[str] = Field(None, description="Additional Terms applicable to Calculation Time for Initial Margin")
    """
          Additional Terms applicable to Calculation Time for Initial Margin
    """

    @cdm_condition
    def condition_0_AsCalculationAgentIm(self):
        """
        A data rule to enforce that the terms applicable to Calculation Time for Initial Margin should be specified when the computation time is not as per Calculation Agent
        """
        return if_cond(all_elements(self.asCalculationAgent, "=", False), '((self.bespokeCalculationTimeTerms) is None)', 'True', self)

    @cdm_condition
    def condition_1_BespokeCalculationTimeTerms(self):
        """
        A data rule to enforce that the Calculation Time for Initial Margin shouldn't be specified when the Control Agreement isn't deemed a Credit Support Document with respect to the party(ies).
        """
        return if_cond(all_elements(self.asCalculationAgent, "=", False), '((self.bespokeCalculationTimeTerms) is not None)', 'True', self)


BespokeCalculationTime.update_forward_refs()
