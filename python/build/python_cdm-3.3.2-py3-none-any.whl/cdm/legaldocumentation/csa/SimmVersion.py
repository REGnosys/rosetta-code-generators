from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['SimmVersion']

from cdm.base.staticdata.party.CounterpartyRoleEnum import CounterpartyRoleEnum

class SimmVersion(BaseDataClass):
    """
    A class to specify the ISDA SIMM version that applies to the ISDA 2018 CSA for Initial Margin. According to the ISDA 2018 CSA for Initial Margin, Paragraph 13, General Principles (ee) (1) provisions, the SIMM version is either not specified, or references a version used by one of the parties to the agreement.
    """
    asSpecified: Optional[str] = Field(None, description="The SIMM version exception when specified as a customized approach by the party.")
    """
          The SIMM version exception when specified as a customized approach by the party.
    """
    isSpecified: Optional[bool] = Field(None, description="A boolean attribute to determine whether the SIMM version is specified for the purpose of the legal agreement.")
    """
          A boolean attribute to determine whether the SIMM version is specified for the purpose of the legal agreement.
    """
    partyVersion: Optional[CounterpartyRoleEnum] = Field(None, description="The party which the specified SIMM version applies to.")
    """
          The party which the specified SIMM version applies to.
    """

    @cdm_condition
    def condition_0_VersionNotSpecified(self):
        """
        A data rule to enforce that the version attribute should be absent when the SIMM version is stated as not specified for the CSA.
        """
        return if_cond(all_elements(self.isSpecified, "=", False), '((self.partyVersion) is None)', 'True', self)

    @cdm_condition
    def condition_1_VersionSpecified(self):
        """
        A data rule to enforce that the version attribute should be specified when the SIMM version is stated as specified for the CSA.
        """
        return if_cond(all_elements(self.isSpecified, "=", False), '((self.partyVersion) is not None)', 'True', self)


SimmVersion.update_forward_refs()
