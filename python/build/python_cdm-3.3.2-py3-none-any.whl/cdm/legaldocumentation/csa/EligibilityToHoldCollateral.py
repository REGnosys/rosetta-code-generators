from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['EligibilityToHoldCollateral']

from cdm.legaldocumentation.csa.HoldingPostedCollateralEnum import HoldingPostedCollateralEnum

class EligibilityToHoldCollateral(BaseDataClass):
    """
    A class to specify the conditions under which a party and its custodian(s) are entitled to hold collateral. ISDA 2016 Credit Support Annex for Variation Margin, paragraph 13, (h)(i): Eligibility to Hold Posted Collateral (VM) Custodians (VM).
    """
    custodianTerms: Optional[CustodianTerms] = Field(None, description="The restrictions that might be required by a party from the other party's custodian agent to hold its posted collateral.")
    """
          The restrictions that might be required by a party from the other party's custodian agent to hold its posted collateral.
    """
    eligibleCountry: Optional[List[AttributeWithMeta[str] | str]] = Field(None, description="The restrictions that might be required by a party from the other party in terms of country(ies) where collateral can be held.")
    """
          The restrictions that might be required by a party from the other party in terms of country(ies) where collateral can be held.
    """
    partyTerms: List[HoldingPostedCollateralEnum] = Field(None, description="The condition(s) required by a party from the other party to hold its posted collateral.")
    """
          The condition(s) required by a party from the other party to hold its posted collateral.
    """
    @cdm_condition
    def cardinality_partyTerms(self):
        return check_cardinality(self.partyTerms, 1, None)


from cdm.legaldocumentation.csa.CustodianTerms import CustodianTerms

EligibilityToHoldCollateral.update_forward_refs()
