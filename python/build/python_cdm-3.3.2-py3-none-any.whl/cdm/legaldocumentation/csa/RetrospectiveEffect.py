from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['RetrospectiveEffect']

from cdm.legaldocumentation.csa.ExceptionEnum import ExceptionEnum

class RetrospectiveEffect(BaseDataClass):
    """
    A class to specify the retrospective effect exception to the regulatory regime clause of Initial Margin documents as either a normalized value specified as part of an enumeration or a customized value specified of type string.
    """
    asSpecified: Optional[str] = Field(None, description="The Standard Initial Margin Model exception when specified as a customized approach by the party.")
    """
          The Standard Initial Margin Model exception when specified as a customized approach by the party.
    """
    standardisedException: Optional[ExceptionEnum] = Field(None, description="The Standard Initial Margin Model exception when specified by the party according to one of the enumerated values.")
    """
          The Standard Initial Margin Model exception when specified by the party according to one of the enumerated values.
    """


RetrospectiveEffect.update_forward_refs()
