from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['SimmCalculationCurrency']


class SimmCalculationCurrency(BaseDataClass):
    """
    A class to specify the SIMM Calculation Currency elections by each party to the agreement.
    """
    partyElection: List[CalculationCurrencyElection] = Field(None, description="The parties' SIMM Calculation Currency election.")
    """
          The parties' SIMM Calculation Currency election.
    """
    @cdm_condition
    def cardinality_partyElection(self):
        return check_cardinality(self.partyElection, 2, 2)


from cdm.legaldocumentation.csa.CalculationCurrencyElection import CalculationCurrencyElection

SimmCalculationCurrency.update_forward_refs()
