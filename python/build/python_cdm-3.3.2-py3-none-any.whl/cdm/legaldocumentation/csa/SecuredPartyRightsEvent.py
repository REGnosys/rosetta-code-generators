from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['SecuredPartyRightsEvent']


class SecuredPartyRightsEvent(BaseDataClass):
    """
    A class to specify Secured Party Rights Event language
    """
    earlyTerminationDateOptionalLanguage: bool = Field(..., description="A boolean attribute to specify whether Failure to Pay Early Termination language is included (True) or excluded (False) from the agreement.")
    """
          A boolean attribute to specify whether Failure to Pay Early Termination language is included (True) or excluded (False) from the agreement.
    """
    failureToPayEarlyTermination: Optional[bool] = Field(None, description="A boolean attribute to specify whether Failure to Pay Early Termination language in the agreement is deemed applicable or not.")
    """
          A boolean attribute to specify whether Failure to Pay Early Termination language in the agreement is deemed applicable or not.
    """
    securedPartyRightsEventElection: Optional[List[SecuredPartyRightsEventElection]] = Field(None, description="")
    @cdm_condition
    def cardinality_securedPartyRightsEventElection(self):
        return check_cardinality(self.securedPartyRightsEventElection, 0, 2)


    @cdm_condition
    def condition_0_FailureToPayLanguage(self):
        """
        A data rule to enforce that the applicability of Failure to Pay language is only applied when Early Termination language is included.
        """
        return if_cond(all_elements(self.earlyTerminationDateOptionalLanguage, "=", False), '((self.failureToPayEarlyTermination) is None)', 'True', self)

from cdm.legaldocumentation.csa.SecuredPartyRightsEventElection import SecuredPartyRightsEventElection

SecuredPartyRightsEvent.update_forward_refs()
