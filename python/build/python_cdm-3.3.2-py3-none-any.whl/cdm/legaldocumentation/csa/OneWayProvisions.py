from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['OneWayProvisions']

from cdm.base.staticdata.party.CounterpartyRoleEnum import CounterpartyRoleEnum

class OneWayProvisions(BaseDataClass):
    """
    A class to specify whether One Way Provisions apply in relation to the ISDA CSA for Initial Margin and, if yes, to specify the Posting Party. ISDA 2016 Credit Support Annex for Initial Margin, paragraph 13, General Principles (aa): One Way Provisions.
    """
    isApplicable: bool = Field(..., description="The determination of whether the One Way Provisions are applicable (true) or not applicable (false).")
    """
          The determination of whether the One Way Provisions are applicable (true) or not applicable (false).
    """
    postingParty: Optional[CounterpartyRoleEnum] = Field(None, description="The Posting Party for the purposes of One Way Provisions. It is specified in the case where the One Way Provision is deemed applicable.")
    """
          The Posting Party for the purposes of One Way Provisions. It is specified in the case where the One Way Provision is deemed applicable.
    """

    @cdm_condition
    def condition_0_PostingPartyExists(self):
        """
        A data rule to enforce that the Posting Party must be specified in the case where the One Way Provision is deemed applicable.
        """
        return if_cond(all_elements(self.isApplicable, "=", False), '((self.postingParty) is not None)', 'True', self)

    @cdm_condition
    def condition_1_PostingPartyAbsent(self):
        """
        A data rule to enforce that the Posting Party must not be specified in the case where the One Way Provision is not deemed applicable.
        """
        return if_cond(all_elements(self.isApplicable, "=", False), '((self.postingParty) is None)', 'True', self)


OneWayProvisions.update_forward_refs()
