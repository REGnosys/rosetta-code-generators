from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['ExecutionTerms']


class ExecutionTerms(BaseDataClass):
    """
    A class to specify execution location and language of execution to determine duty to be paid.
    """
    executionLanguage: ExecutionLanguage = Field(..., description="The bespoke execution language election.")
    """
          The bespoke execution language election.
    """
    executionLocation: ExecutionLocation = Field(..., description="The bespoke execution location election.")
    """
          The bespoke execution location election.
    """

from cdm.legaldocumentation.csa.ExecutionLanguage import ExecutionLanguage
from cdm.legaldocumentation.csa.ExecutionLocation import ExecutionLocation

ExecutionTerms.update_forward_refs()
