from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['BespokeCalculationDate']


class BespokeCalculationDate(BaseDataClass):
    """
    A class to specify bespoke Calculation Date terms for the purposes of Initial Margin
    """
    calculationDateImTerms: Optional[str] = Field(None, description="The Additional Calculation Date terms for the purposes of Initial Margin")
    """
          The Additional Calculation Date terms for the purposes of Initial Margin
    """
    isApplicable: bool = Field(..., description="Additional Calculation Date terms are applicable when True and not applicable when False")
    """
          Additional Calculation Date terms are applicable when True and not applicable when False
    """

    @cdm_condition
    def condition_0_CalculationDateImTerms(self):
        """
        A data rule to enforce that Additional Calculation Date Terms should be absent when not applicable
        """
        return if_cond(all_elements(self.isApplicable, "=", False), '((self.calculationDateImTerms) is None)', 'True', self)


BespokeCalculationDate.update_forward_refs()
