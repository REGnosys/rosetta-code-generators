from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['ExecutionLocation']

from cdm.legaldocumentation.common.ExecutionLocationEnum import ExecutionLocationEnum

class ExecutionLocation(BaseDataClass):
    """
    A class to specify execution location terms of a Security Agreement
    """
    dutyPayer: Optional[str] = Field(None, description="The payer of documentary duty")
    """
          The payer of documentary duty
    """
    dutyPayerLanguage: Optional[str] = Field(None, description="Bespoke terms specific to the payment of documentary duty")
    """
          Bespoke terms specific to the payment of documentary duty
    """
    dutyPaymentDate: Optional[date] = Field(None, description="The date that documentary duty will be paid")
    """
          The date that documentary duty will be paid
    """
    dutyPaymentLanguage: Optional[str] = Field(None, description="Bespoke terms specific to the date that documentary duty will be paid")
    """
          Bespoke terms specific to the date that documentary duty will be paid
    """
    executionLocation: ExecutionLocationEnum = Field(..., description="The execution location of the agreement")
    """
          The execution location of the agreement
    """
    otherLanguage: Optional[str] = Field(None, description="Bespoke execution location language to be included when specified.")
    """
          Bespoke execution location language to be included when specified.
    """

    @cdm_condition
    def condition_0_DutyPayerLanguage(self):
        """
        A data rule to enforce that Duty Payer Language should only be specified when required
        """
        return if_cond(all_elements(self.dutyPayer, "=", "Specify"), '((self.dutyPayerLanguage) is not None)', 'True', self)

    @cdm_condition
    def condition_1_DutyPaymentLanguage(self):
        """
        A data rule to enforce that Duty Payment Language should be absent when a Duty Payment date is provided
        """
        return if_cond(((self.dutyPaymentDate) is not None), '((self.dutyPaymentLanguage) is None)', 'True', self)

    @cdm_condition
    def condition_2_OtherLanguage(self):
        """
        A data rule to enforce that bespoke execution language must be included if non-standard execution language is specified.
        """
        return if_cond(all_elements(self.executionLocation, "=", ExecutionLocationEnum.OtherLocation), '((self.otherLanguage) is not None)', 'True', self)

from cdm.legaldocumentation.common.ExecutionLocationEnum import ExecutionLocationEnum

ExecutionLocation.update_forward_refs()
