from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['FrenchLawAddendumElection']

from cdm.base.staticdata.party.CounterpartyRoleEnum import CounterpartyRoleEnum

class FrenchLawAddendumElection(BaseDataClass):
    """
    A class to specify party specific French Law Addendum language
    """
    addendumLanguage: Optional[str] = Field(None, description="The party specific language to be included in the agreement.")
    """
          The party specific language to be included in the agreement.
    """
    isApplicable: bool = Field(..., description="The qualification of whether the party elects specific language")
    """
          The qualification of whether the party elects specific language
    """
    party: CounterpartyRoleEnum = Field(..., description="The elective party.")
    """
          The elective party.
    """

    @cdm_condition
    def condition_0_AddendumLanguage(self):
        """
        A data rule to enforce that the French Law Addendum party language must be specified when applicable.
        """
        return if_cond(all_elements(self.isApplicable, "=", False), '((self.addendumLanguage) is not None)', 'if_cond(all_elements(self.isApplicable, "=", False), \'((self.addendumLanguage) is None)\', \'True\', self)', self)


FrenchLawAddendumElection.update_forward_refs()
