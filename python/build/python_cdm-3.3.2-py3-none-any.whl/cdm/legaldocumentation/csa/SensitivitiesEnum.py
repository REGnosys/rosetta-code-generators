from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['SensitivitiesEnum']

from enum import Enum

class SensitivitiesEnum(Enum):
    """
    The enumerated values to specify the methodology according to which sensitivities to (i) equity indices, funds and ETFs, and (ii) commodity indices are computed. ISDA 2016 Credit Support Annex for Initial Margin, paragraph 13, General Principles, (gg)(2).
    """
    ALTERNATIVE = "ALTERNATIVE"
    """
    The parties agree that in respect of the relevant sensitivities, the delta is allocated back to individual constituents.
    """
    STANDARD = "STANDARD"
    """
    The relevant sensitivities are addressed by the standard preferred approach where the entire delta is put into the applicable asset class/category.
    """
