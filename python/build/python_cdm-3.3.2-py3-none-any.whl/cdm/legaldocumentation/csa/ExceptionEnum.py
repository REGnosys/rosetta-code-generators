from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['ExceptionEnum']

from enum import Enum

class ExceptionEnum(Enum):
    """
    The enumerated values to specify the normalized exceptions applicable to an Initial Margin CSA.
    """
    APPLICABLE = "APPLICABLE"
    """
    The election is applicable.
    """
    NOT_APPLICABLE = "NOT_APPLICABLE"
    """
    The exception is not applicable. ISDA 2016 Credit Support Annex for Initial Margin, paragraph 13, General Principles. | ISDA 2018 Credit Support Annex for Initial Margin, paragraph 13, General Principles.
    """
    OTHER = "OTHER"
    """
    An alternative approach is described in the document as follows.
    """
