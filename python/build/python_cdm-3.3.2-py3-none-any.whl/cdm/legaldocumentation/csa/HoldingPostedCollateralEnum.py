from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['HoldingPostedCollateralEnum']

from enum import Enum

class HoldingPostedCollateralEnum(Enum):
    """
    The enumerated values to specify condition(s) required by a party from the other party to hold its posted collateral. ISDA 2016 Credit Support Annex for Variation Margin, paragraph 13, (h)(i): Eligibility to Hold Posted Collateral (VM); Custodians (VM).
    """
    ACCEPTABLE_CUSTODIAN = "ACCEPTABLE_CUSTODIAN"
    """
    The custodian is acceptable to the other party to the agreement.
    """
