from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['SpecifiedEntity']

from cdm.legaldocumentation.common.SpecifiedEntityTermsEnum import SpecifiedEntityTermsEnum

class SpecifiedEntity(BaseDataClass):
    """
    Description
    """
    materialSubsidiaryTerms: Optional[str] = Field(None, description="The meaning of Material Subsidiary for the Event of Default or Termination Event specified.")
    """
          The meaning of Material Subsidiary for the Event of Default or Termination Event specified.
    """
    otherSpecifiedEntityTerms: Optional[str] = Field(None, description="The non standard terms for the Event of Default or Termination Event specified.")
    """
          The non standard terms for the Event of Default or Termination Event specified.
    """
    party: Party = Field(..., description="The elective party")
    """
          The elective party
    """
    specifiedEntity: Optional[List[LegalEntity]] = Field(None, description="The specified entities for the Event of Default or Termination Event specified.")
    """
          The specified entities for the Event of Default or Termination Event specified.
    """
    specifiedEntityTerms: SpecifiedEntityTermsEnum = Field(..., description="The specified entity terms for the Event of Default or Termination Event specified.")
    """
          The specified entity terms for the Event of Default or Termination Event specified.
    """

    @cdm_condition
    def condition_0_SpecifiedEntity(self):
        """
        A validation rule to ensure that a SpecifiedEntity is specified when required.
        """
        return if_cond(all_elements(self.specifiedEntityTerms, "=", SpecifiedEntityTermsEnum.NamedSpecifiedEntity), '((self.specifiedEntity) is not None)', 'True', self)

    @cdm_condition
    def condition_1_MaterialSubsidiary(self):
        """
        A validation rule to ensure that Material Subsidiary terms are specified when required.
        """
        return if_cond(all_elements(self.specifiedEntityTerms, "=", SpecifiedEntityTermsEnum.MaterialSubsidiary), '((self.materialSubsidiaryTerms) is not None)', 'True', self)

    @cdm_condition
    def condition_2_OtherSpecifiedEntity(self):
        """
        A validation rule to ensure that non standard Specified Entity terms are provided when required.
        """
        return if_cond(all_elements(self.specifiedEntityTerms, "=", SpecifiedEntityTermsEnum.OtherSpecifiedEntity), '((self.otherSpecifiedEntityTerms) is not None)', 'True', self)

from cdm.base.staticdata.party.Party import Party
from cdm.base.staticdata.party.LegalEntity import LegalEntity
from cdm.legaldocumentation.common.SpecifiedEntityTermsEnum import SpecifiedEntityTermsEnum

SpecifiedEntity.update_forward_refs()
