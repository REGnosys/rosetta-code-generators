from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['TerminationCurrencySelection']


class TerminationCurrencySelection(BaseDataClass):
    """
    Specifies Termination Currency where a currency is stated at the time the agreement is entered into.
    """
    bothAffected: Optional[str] = Field(None, description="Specifies fallback Termination Currency where both parties are Affected Parties.")
    """
          Specifies fallback Termination Currency where both parties are Affected Parties.
    """
    fallbackCurrency: Optional[str] = Field(None, description="Specifies a single fallback Termination Currency should the stated currency not be freely available.")
    """
          Specifies a single fallback Termination Currency should the stated currency not be freely available.
    """
    partyElection: Optional[List[PartyTerminationCurrencySelection]] = Field(None, description="Specifies different termination currencies to apply depending on which party or parties are the Defaulting Party Affected Party(ies).")
    """
          Specifies different termination currencies to apply depending on which party or parties are the Defaulting Party Affected Party(ies).
    """
    @cdm_condition
    def cardinality_partyElection(self):
        return check_cardinality(self.partyElection, 0, 2)

    statedCurrency: Optional[str] = Field(None, description="Specifies a single Termination Currency for the agreement.")
    """
          Specifies a single Termination Currency for the agreement.
    """

from cdm.legaldocumentation.master.PartyTerminationCurrencySelection import PartyTerminationCurrencySelection

TerminationCurrencySelection.update_forward_refs()
