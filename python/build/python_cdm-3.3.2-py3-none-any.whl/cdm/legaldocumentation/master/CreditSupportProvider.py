from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CreditSupportProvider']


class CreditSupportProvider(BaseDataClass):
    """
    Identification of party specific Credit Support Providers applicable to the document.
    """
    creditSupportProviderElection: List[CreditSupportProviderElection] = Field(None, description="The party election of Credit Support Provider(s), if any.")
    """
          The party election of Credit Support Provider(s), if any.
    """
    @cdm_condition
    def cardinality_creditSupportProviderElection(self):
        return check_cardinality(self.creditSupportProviderElection, 2, 2)


from cdm.legaldocumentation.master.CreditSupportProviderElection import CreditSupportProviderElection

CreditSupportProvider.update_forward_refs()
