from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['PartyOptionTerminationCurrency']

from cdm.legaldocumentation.common.TerminationCurrencyConditionEnum import TerminationCurrencyConditionEnum

class PartyOptionTerminationCurrency(BaseDataClass):
    """
    Specifies mechanism for Termination currency to be selected by the Non-defaulting Party/party which is not the Affected Party.
    """
    bothAffectedTermCurrencyOption: Optional[str] = Field(None, description="Specifies termination currency where there are two Affected Parties and they cannot agree on the termination currency.")
    """
          Specifies termination currency where there are two Affected Parties and they cannot agree on the termination currency.
    """
    terminationCurrencyCondition: TerminationCurrencyConditionEnum = Field(..., description="Specifies the enumerated conditions for selection of the termination currency.")
    """
          Specifies the enumerated conditions for selection of the termination currency.
    """
    terminationCurrencySpecifiedCondition: Optional[str] = Field(None, description="Specifies alternative conditions for selection of the termination currency.")
    """
          Specifies alternative conditions for selection of the termination currency.
    """

    @cdm_condition
    def condition_0_TerminationCurrencyCondition(self):
        """
        A validation rule to ensure that Termination Currency alternative conditions are specified when required.
        """
        return if_cond(all_elements(self.terminationCurrencyCondition, "=", TerminationCurrencyConditionEnum.Specified), '((self.terminationCurrencySpecifiedCondition) is not None)', 'True', self)

from cdm.legaldocumentation.common.TerminationCurrencyConditionEnum import TerminationCurrencyConditionEnum

PartyOptionTerminationCurrency.update_forward_refs()
