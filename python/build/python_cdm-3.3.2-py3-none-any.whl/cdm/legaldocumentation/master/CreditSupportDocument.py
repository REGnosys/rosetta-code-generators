from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CreditSupportDocument']


class CreditSupportDocument(BaseDataClass):
    """
    Identification of party specific Credit Support Documents applicable to the document.
    """
    creditSupportDocumentElection: List[CreditSupportDocumentElection] = Field(None, description="The party election of Credit Support Document(s), if any.")
    """
          The party election of Credit Support Document(s), if any.
    """
    @cdm_condition
    def cardinality_creditSupportDocumentElection(self):
        return check_cardinality(self.creditSupportDocumentElection, 2, 2)


from cdm.legaldocumentation.master.CreditSupportDocumentElection import CreditSupportDocumentElection

CreditSupportDocument.update_forward_refs()
