from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CreditSupportDocumentElection']

from cdm.legaldocumentation.common.CreditSupportDocumentTermsEnum import CreditSupportDocumentTermsEnum

class CreditSupportDocumentElection(BaseDataClass):
    """
    The party election of Credit Support Provider(s), if any.
    """
    bespokeCreditSuppportDocument: Optional[str] = Field(None, description="Specification of a document when not captured under RelatedAgreement")
    """
          Specification of a document when not captured under RelatedAgreement
    """
    creditSupportDocument: Optional[List[LegalAgreement]] = Field(None, description="The specified Credit Support Document(s), if any.")
    """
          The specified Credit Support Document(s), if any.
    """
    creditSupportDocumentTerms: CreditSupportDocumentTermsEnum = Field(..., description="Specification of the Credit Support Document terms.")
    """
          Specification of the Credit Support Document terms.
    """
    party: Party = Field(..., description="The elective party")
    """
          The elective party
    """

    @cdm_condition
    def condition_0_CreditSupportDocument(self):
        """
        A validation rule to ensure that a Credit Support Document is specified when required.
        """
        return if_cond(all_elements(self.creditSupportDocumentTerms, "=", CreditSupportDocumentTermsEnum.Specified), '((self.creditSupportDocument) is not None)', 'True', self)

from cdm.legaldocumentation.common.LegalAgreement import LegalAgreement
from cdm.base.staticdata.party.Party import Party
from cdm.legaldocumentation.common.CreditSupportDocumentTermsEnum import CreditSupportDocumentTermsEnum

CreditSupportDocumentElection.update_forward_refs()
