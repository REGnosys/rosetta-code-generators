from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['EquityMasterConfirmation']

from cdm.legaldocumentation.master.MasterConfirmationBase import MasterConfirmationBase

class EquityMasterConfirmation(MasterConfirmationBase):
    """
    Specification for General Terms and Elections of an Equity Master Confirmation that is applicable across multiple Equity confirmations and is referenced by each of these confirmations, an example of which being the 2018 ISDA CDM Equity Confirmation for Security Equity Swap.
    """
    pass


EquityMasterConfirmation.update_forward_refs()
