from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['SpecifiedEntities']

from cdm.legaldocumentation.common.SpecifiedEntityClauseEnum import SpecifiedEntityClauseEnum

class SpecifiedEntities(BaseDataClass):
    """
    A provision that allows each party to specify its Specified Entities for certain Events of Default and Termination Events
    """
    specifiedEntity: List[SpecifiedEntity] = Field(None, description="The party specific election of Specified Entities for the Event of Default or Termination Event specified.")
    """
          The party specific election of Specified Entities for the Event of Default or Termination Event specified.
    """
    @cdm_condition
    def cardinality_specifiedEntity(self):
        return check_cardinality(self.specifiedEntity, 2, 2)

    specifiedEntityClause: SpecifiedEntityClauseEnum = Field(..., description="The Event of Default or Termination event for which Specified Entities terms are being defined.")
    """
          The Event of Default or Termination event for which Specified Entities terms are being defined.
    """

from cdm.legaldocumentation.master.SpecifiedEntity import SpecifiedEntity

SpecifiedEntities.update_forward_refs()
