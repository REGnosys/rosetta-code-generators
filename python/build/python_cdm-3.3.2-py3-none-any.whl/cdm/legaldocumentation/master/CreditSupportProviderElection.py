from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CreditSupportProviderElection']

from cdm.legaldocumentation.common.CreditSupportProviderTermsEnum import CreditSupportProviderTermsEnum

class CreditSupportProviderElection(BaseDataClass):
    """
    The party election of Credit Support Provider(s), if any.
    """
    bespokeCreditSuppportProvider: Optional[str] = Field(None, description="...")
    """
          ...
    """
    creditSupportProvider: Optional[List[LegalEntity]] = Field(None, description="The specified Credit Support Provider(s), if any.")
    """
          The specified Credit Support Provider(s), if any.
    """
    creditSupportProviderTerms: CreditSupportProviderTermsEnum = Field(..., description="Specification of the Credit Support Provider terms.")
    """
          Specification of the Credit Support Provider terms.
    """
    party: Party = Field(..., description="The elective party")
    """
          The elective party
    """

    @cdm_condition
    def condition_0_CreditSupportProvider(self):
        """
        A validation rule to ensure that a Credit Support Provider is specified when required.
        """
        return if_cond(all_elements(self.creditSupportProviderTerms, "=", CreditSupportProviderTermsEnum.Specified), '((self.creditSupportProvider) is not None)', 'True', self)

from cdm.base.staticdata.party.LegalEntity import LegalEntity
from cdm.base.staticdata.party.Party import Party
from cdm.legaldocumentation.common.CreditSupportProviderTermsEnum import CreditSupportProviderTermsEnum

CreditSupportProviderElection.update_forward_refs()
