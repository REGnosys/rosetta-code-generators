from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['LegalAgreementPublisherEnum']

from enum import Enum

class LegalAgreementPublisherEnum(Enum):
    """
    The enumerated values to specify the legal agreement publisher.
    """
    AFB = "AFB"
    """
    Association Française des Banques.
    """
    BNYM = "BNYM"
    """
    BNY Mellon
    """
    ISDA = "ISDA"
    """
    International Swaps and Derivatives Association, Inc.
    """
    ISDA_CLEARSTREAM = "ISDA_CLEARSTREAM"
    """
    ISDA and Clearstream
    """
    ISDA_EUROCLEAR = "ISDA_EUROCLEAR"
    """
    ISDA and Euroclear
    """
    ISLA = "ISLA"
    """
    International Securities Lending Association
    """
    JP_MORGAN = "JP_MORGAN"
    """
    JP Morgan
    """
