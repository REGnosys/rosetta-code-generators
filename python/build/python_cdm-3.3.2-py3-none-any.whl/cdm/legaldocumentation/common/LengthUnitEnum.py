from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['LengthUnitEnum']

from enum import Enum

class LengthUnitEnum(Enum):
    """
    The enumerated values to specify the length unit in the Resource type.
    """
    PAGES = "PAGES"
    TIME_UNIT = "TIME_UNIT"
