from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['LegalAgreementIdentification']

from cdm.legaldocumentation.common.GoverningLawEnum import GoverningLawEnum
from cdm.legaldocumentation.common.LegalAgreementPublisherEnum import LegalAgreementPublisherEnum

class LegalAgreementIdentification(BaseDataClass):
    """
    Specifies the type of legal agreement, identified via a set of composable attributes: agreementName, publisher, governing law and version, e.g. ISDA 2013 Standard Credit Support Annex English Law.
    """
    agreementName: AgreementName = Field(..., description="The legal agreement name, e.g. Credit Support Annex for Variation Margin.")
    """
          The legal agreement name, e.g. Credit Support Annex for Variation Margin.
    """
    governingLaw: Optional[GoverningLawEnum] = Field(None, description="The law governing the legal agreement, e.g. English Law, New York Law or Japanese Law.")
    """
          The law governing the legal agreement, e.g. English Law, New York Law or Japanese Law.
    """
    publisher: Optional[LegalAgreementPublisherEnum] = Field(None, description="The legal agreement publisher, e.g. ISDA.")
    """
          The legal agreement publisher, e.g. ISDA.
    """
    vintage: Optional[int] = Field(None, description="In the case where successive definitions of the legal agreement have been developed, the vintage identification. This is typically (but not necessarily) done by referencing the year, e.g. 2013 in the case of the ISDA 2013 Standard Credit Support Annex.")
    """
          In the case where successive definitions of the legal agreement have been developed, the vintage identification. This is typically (but not necessarily) done by referencing the year, e.g. 2013 in the case of the ISDA 2013 Standard Credit Support Annex.
    """

    @cdm_condition
    def condition_0_CSAMarginType(self):
        """
        A condition to ensure that CSA margin type is only specified if a credit support agreemnt type is specified and its published vintage year is equal to or after 2016.
        """
        return if_cond(((self.agreementName.creditSupportAgreementMarginType) is not None), '(((self.agreementName.creditSupportAgreementType) is not None) and all_elements(self.vintage, ">=", 2016))', 'True', self)

from cdm.legaldocumentation.common.AgreementName import AgreementName

LegalAgreementIdentification.update_forward_refs()
