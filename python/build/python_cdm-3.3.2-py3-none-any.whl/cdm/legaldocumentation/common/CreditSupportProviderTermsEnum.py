from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CreditSupportProviderTermsEnum']

from enum import Enum

class CreditSupportProviderTermsEnum(Enum):
    """
    The enumerated values to specify the Credit Support Provider Terms
    """
    ANY = "ANY"
    """
    Any party or parties who now or in the future may provide a Credit Support Document or other form of credit support.
    """
    NONE = "NONE"
    """
    No Credit Support Provider is specified.
    """
    SPECIFIED = "SPECIFIED"
    """
    A specified Credit Support Provider is provided
    """
