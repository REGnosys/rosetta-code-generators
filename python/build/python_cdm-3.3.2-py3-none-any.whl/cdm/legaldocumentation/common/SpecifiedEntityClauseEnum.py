from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['SpecifiedEntityClauseEnum']

from enum import Enum

class SpecifiedEntityClauseEnum(Enum):
    """
    The enumerated values to specify the Event of Default or Termination event for which Specified Entities terms are being defined.
    """
    BANKRUPTCY = "BANKRUPTCY"
    CREDIT_EVENT_UPON_MERGER = "CREDIT_EVENT_UPON_MERGER"
    CROSS_DEFAULT = "CROSS_DEFAULT"
    DEFAULT_UNDER_SPECIFIED_TRANSACTION = "DEFAULT_UNDER_SPECIFIED_TRANSACTION"
