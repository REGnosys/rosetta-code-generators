from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['ContractualTermsSupplement']

from cdm.legaldocumentation.common.ContractualSupplementTypeEnum import ContractualSupplementTypeEnum

class ContractualTermsSupplement(BaseDataClass):
    """
    A contractual supplement (such as those published by ISDA) and its publication date that will apply to the trade.
    """
    contractualTermsSupplementType: AttributeWithMeta[ContractualSupplementTypeEnum] | ContractualSupplementTypeEnum = Field(..., description="Identifies the form of applicable contractual supplement.")
    """
          Identifies the form of applicable contractual supplement.
    """
    publicationDate: Optional[date] = Field(None, description="Specifies the publication date of the applicable version of the contractual supplement.")
    """
          Specifies the publication date of the applicable version of the contractual supplement.
    """


ContractualTermsSupplement.update_forward_refs()
