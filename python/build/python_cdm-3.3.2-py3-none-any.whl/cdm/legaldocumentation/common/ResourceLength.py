from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['ResourceLength']

from cdm.legaldocumentation.common.LengthUnitEnum import LengthUnitEnum

class ResourceLength(BaseDataClass):
    """
    A class to indicate the length of the resource.
    """
    lengthUnit: LengthUnitEnum = Field(..., description="The length unit of the resource. For example, pages (pdf, text documents) or time (audio, video files).")
    """
          The length unit of the resource. For example, pages (pdf, text documents) or time (audio, video files).
    """
    lengthValue: float = Field(..., description="The length value of the resource.")
    """
          The length value of the resource.
    """


ResourceLength.update_forward_refs()
