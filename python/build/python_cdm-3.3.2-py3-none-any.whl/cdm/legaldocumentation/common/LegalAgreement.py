from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['LegalAgreement']

from cdm.legaldocumentation.common.LegalAgreementBase import LegalAgreementBase

class LegalAgreement(LegalAgreementBase):
    """
    The specification of a legal agreement between two parties, being negotiated or having been executed. This includes the baseline information and the optional specialised elections
    """
    agreementTerms: Optional[AgreementTerms] = Field(None, description="Specification of the content of the legal agreement.")
    """
          Specification of the content of the legal agreement.
    """
    relatedAgreements: Optional[List[LegalAgreement]] = Field(None, description="Specifies the agreement(s) that govern the agreement, either as a reference to such agreements when specified as part of the CDM, or through identification of some of the key terms of those agreements, such as the type of agreement, the publisher, the vintage, the agreement identifier and the agreement date.")
    """
          Specifies the agreement(s) that govern the agreement, either as a reference to such agreements when specified as part of the CDM, or through identification of some of the key terms of those agreements, such as the type of agreement, the publisher, the vintage, the agreement identifier and the agreement date.
    """
    umbrellaAgreement: Optional[UmbrellaAgreement] = Field(None, description="The determination of whether Umbrella Agreement terms are applicable (True) or Not Applicable (False).")
    """
          The determination of whether Umbrella Agreement terms are applicable (True) or Not Applicable (False).
    """

    @cdm_condition
    def condition_0_ConsistentlyExecutedAgreements(self):
        """
        An executed agreement can only point to executed related agreements if any.
        """
        return if_cond((((self.relatedAgreements) is not None) and ((self.agreementDate) is not None)), '((self.relatedAgreements.agreementDate) is not None)', 'True', self)

    @cdm_condition
    def condition_1_AgreementVerification(self):
        """
        A validation rule to ensure that the agreement elections are associated with the correct legal agreement type as specified.
        """
        return if_cond(((self.agreementTerms.agreement.securityAgreementElections) is not None), 'all_elements(self.legalAgreementIdentification.agreementName.agreementType, "=", LegalAgreementTypeEnum.SecurityAgreement)', 'if_cond(((self.agreementTerms.agreement.creditSupportAgreementElections) is not None), \'(all_elements(self.legalAgreementIdentification.agreementName.creditSupportAgreementType, "=", CreditSupportAgreementTypeEnum.CreditSupportAnnex) or all_elements(self.legalAgreementIdentification.agreementName.creditSupportAgreementType, "=", CreditSupportAgreementTypeEnum.CreditSupportDeed))\', \'if_cond(((self.agreementTerms.agreement.collateralTransferAgreementElections) is not None), \\\'all_elements(self.legalAgreementIdentification.agreementName.creditSupportAgreementType, "=", CreditSupportAgreementTypeEnum.CollateralTransferAgreement)\\\', \\\'if_cond(((self.agreementTerms.agreement.masterAgreementSchedule) is not None), \\\\\\\'all_elements(self.legalAgreementIdentification.agreementName.agreementType, "=", LegalAgreementTypeEnum.MasterAgreement)\\\\\\\', \\\\\\\'True\\\\\\\', self)\\\', self)\', self)', self)

from cdm.legaldocumentation.common.AgreementTerms import AgreementTerms
from cdm.legaldocumentation.common.LegalAgreement import LegalAgreement
from cdm.legaldocumentation.common.UmbrellaAgreement import UmbrellaAgreement
from cdm.legaldocumentation.common.LegalAgreementTypeEnum import LegalAgreementTypeEnum
from cdm.legaldocumentation.csa.CreditSupportAgreementTypeEnum import CreditSupportAgreementTypeEnum

LegalAgreement.update_forward_refs()
