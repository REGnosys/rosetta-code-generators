from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['TerminationCurrencyConditionEnum']

from enum import Enum

class TerminationCurrencyConditionEnum(Enum):
    FREELY_AVAILABLE = "FREELY_AVAILABLE"
    """
    A currency that is freely available.
    """
    PAYMENTS_DUE = "PAYMENTS_DUE"
    """
    A currency in which payments would be due under one or more Transactions.
    """
    PAYMENTS_DUE_AND_FREELY_AVAILABLE = "PAYMENTS_DUE_AND_FREELY_AVAILABLE"
    """
    A currency in which payments would be due under one or more Transactions and that is freely available.
    """
    SPECIFIED = "SPECIFIED"
    """
    Termination Currency Conditions are specified.
    """
