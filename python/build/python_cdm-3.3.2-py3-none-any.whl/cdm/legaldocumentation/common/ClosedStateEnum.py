from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['ClosedStateEnum']

from enum import Enum

class ClosedStateEnum(Enum):
    """
    The enumerated values to specify what led to the contract or execution closure.
    """
    ALLOCATED = "ALLOCATED"
    """
    The execution or contract has been allocated.
    """
    CANCELLED = "CANCELLED"
    """
    The execution or contract has been cancelled.
    """
    EXERCISED = "EXERCISED"
    """
    The (option) contract has been exercised.
    """
    EXPIRED = "EXPIRED"
    """
    The (option) contract has expired without being exercised.
    """
    MATURED = "MATURED"
    """
    The contract has reached its contractual termination date.
    """
    NOVATED = "NOVATED"
    """
    The contract has been novated. This state applies to the stepped-out contract component of the novation event.
    """
    TERMINATED = "TERMINATED"
    """
    The contract has been subject of an early termination event.
    """
