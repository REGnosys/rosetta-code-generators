from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['AgreementName']

from cdm.legaldocumentation.common.LegalAgreementTypeEnum import LegalAgreementTypeEnum
from cdm.legaldocumentation.contract.BrokerConfirmationTypeEnum import BrokerConfirmationTypeEnum
from cdm.legaldocumentation.common.ContractualDefinitionsEnum import ContractualDefinitionsEnum
from cdm.legaldocumentation.common.CreditSupportAgreementMarginTypeEnum import CreditSupportAgreementMarginTypeEnum
from cdm.legaldocumentation.csa.CreditSupportAgreementTypeEnum import CreditSupportAgreementTypeEnum
from cdm.legaldocumentation.master.MasterAgreementTypeEnum import MasterAgreementTypeEnum
from cdm.legaldocumentation.master.MasterConfirmationAnnexTypeEnum import MasterConfirmationAnnexTypeEnum
from cdm.legaldocumentation.master.MasterConfirmationTypeEnum import MasterConfirmationTypeEnum

class AgreementName(BaseDataClass):
    """
    Specifies the agreement name through an agreement type and optional detailed sub agreement type.
    """
    agreementType: LegalAgreementTypeEnum = Field(..., description="Specification of the legal agreement type.")
    """
          Specification of the legal agreement type.
    """
    brokerConfirmationType: Optional[BrokerConfirmationTypeEnum] = Field(None, description="Specification of the broker confirmation type.")
    """
          Specification of the broker confirmation type.
    """
    contractualDefinitionsType: Optional[List[AttributeWithMeta[ContractualDefinitionsEnum] | ContractualDefinitionsEnum]] = Field(None, description="The definitions such as those published by ISDA that will define the terms of the trade.")
    """
          The definitions such as those published by ISDA that will define the terms of the trade.
    """
    contractualMatrix: Optional[List[ContractualMatrix]] = Field(None, description="A reference to a contractual matrix of elected terms/values (such as those published by ISDA) that shall be deemed to apply to the trade. The applicable matrix is identified by reference to a name and optionally a publication date. Depending on the structure of the matrix, an additional term (specified in the matrixTerm element) may be required to further identify a subset of applicable terms/values within the matrix.")
    """
          A reference to a contractual matrix of elected terms/values (such as those published by ISDA) that shall be deemed to apply to the trade. The applicable matrix is identified by reference to a name and optionally a publication date. Depending on the structure of the matrix, an additional term (specified in the matrixTerm element) may be required to further identify a subset of applicable terms/values within the matrix.
    """
    contractualTermsSupplement: Optional[List[ContractualTermsSupplement]] = Field(None, description="A contractual supplement (such as those published by ISDA) that will apply to the trade.")
    """
          A contractual supplement (such as those published by ISDA) that will apply to the trade.
    """
    creditSupportAgreementMarginType: Optional[CreditSupportAgreementMarginTypeEnum] = Field(None, description="specifies the type of margin for which a legal agreement is named.")
    """
          specifies the type of margin for which a legal agreement is named.
    """
    creditSupportAgreementType: Optional[AttributeWithMeta[CreditSupportAgreementTypeEnum] | CreditSupportAgreementTypeEnum] = Field(None, description="Specification of the credit support agreement type.")
    """
          Specification of the credit support agreement type.
    """
    masterAgreementType: Optional[AttributeWithMeta[MasterAgreementTypeEnum] | MasterAgreementTypeEnum] = Field(None, description="Specification of the master agreement type.")
    """
          Specification of the master agreement type.
    """
    masterConfirmationAnnexType: Optional[AttributeWithMeta[MasterConfirmationAnnexTypeEnum] | MasterConfirmationAnnexTypeEnum] = Field(None, description="The type of master confirmation annex executed between the parties.")
    """
          The type of master confirmation annex executed between the parties.
    """
    masterConfirmationType: Optional[AttributeWithMeta[MasterConfirmationTypeEnum] | MasterConfirmationTypeEnum] = Field(None, description="The type of master confirmation executed between the parties.")
    """
          The type of master confirmation executed between the parties.
    """
    otherAgreement: Optional[str] = Field(None, description="Definition of an agreement that is not enumerated in the CDM.")
    """
          Definition of an agreement that is not enumerated in the CDM.
    """

    @cdm_condition
    def condition_0_AgreementType(self):
        """
        A condition to ensure that the agreement type specified is consistent with the detailed documentation identified.
        """
        return if_cond(any_elements(self.agreementType, "<>", LegalAgreementTypeEnum.Other), '((self.otherAgreement) is None)', 'if_cond(any_elements(self.agreementType, "<>", LegalAgreementTypeEnum.MasterAgreement), \'((self.masterAgreementType) is None)\', \'if_cond(any_elements(self.agreementType, "<>", LegalAgreementTypeEnum.BrokerConfirmation), \\\'((self.brokerConfirmationType) is None)\\\', \\\'if_cond(any_elements(self.agreementType, "<>", LegalAgreementTypeEnum.MasterConfirmation), \\\\\\\'(((self.masterConfirmationType) is None) and ((self.masterConfirmationAnnexType) is None))\\\\\\\', \\\\\\\'if_cond(any_elements(self.agreementType, "<>", LegalAgreementTypeEnum.Confirmation), \\\\\\\\\\\\\\\'((((self.contractualDefinitionsType) is None) and ((self.contractualTermsSupplement) is None)) and ((self.contractualMatrix) is None))\\\\\\\\\\\\\\\', \\\\\\\\\\\\\\\'True\\\\\\\\\\\\\\\', self)\\\\\\\', self)\\\', self)\', self)', self)

    @cdm_condition
    def condition_1_CreditSupportAgreement(self):
        """
        A condition to ensure that the credit supoort agreement type is specified when required.
        """
        return if_cond(all_elements(self.agreementType, "=", LegalAgreementTypeEnum.CreditSupportAgreement), '((self.creditSupportAgreementType) is not None)', 'True', self)

    @cdm_condition
    def condition_2_MasterConfirmation(self):
        """
        If a master confirmation annex type is specified a master confirmation type must exist.
        """
        return if_cond(((self.masterConfirmationAnnexType) is not None), '((self.masterConfirmationType) is not None)', 'True', self)

    @cdm_condition
    def condition_3_CSAMarginType(self):
        """
        A condition to ensure that CSA margin type is only specified if a credit support agreemnt type is specified.
        """
        return if_cond(((self.creditSupportAgreementMarginType) is not None), '((self.creditSupportAgreementType) is not None)', 'True', self)

from cdm.legaldocumentation.common.ContractualMatrix import ContractualMatrix
from cdm.legaldocumentation.common.ContractualTermsSupplement import ContractualTermsSupplement
from cdm.legaldocumentation.common.LegalAgreementTypeEnum import LegalAgreementTypeEnum

AgreementName.update_forward_refs()
