from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['ExecutionLocationEnum']

from enum import Enum

class ExecutionLocationEnum(Enum):
    """
    The enumerated values to specify the Execution Location of a Security Agreement
    """
    EXECUTED_IN_BELGIUM = "EXECUTED_IN_BELGIUM"
    """
    The Agreement was executed outside of Belgium
    """
    EXECUTED_OUTSIDE_BELGIUM = "EXECUTED_OUTSIDE_BELGIUM"
    """
    The Agreement was executed outside of Belgium
    """
    OTHER_LOCATION = "OTHER_LOCATION"
    """
    An alternative approach is described in the document as follows.
    """
