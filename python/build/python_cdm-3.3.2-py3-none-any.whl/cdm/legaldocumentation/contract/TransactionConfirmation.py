from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['TransactionConfirmation']


class TransactionConfirmation(BaseDataClass):
    """
    See existing Contract type
    """
    pass


TransactionConfirmation.update_forward_refs()
