from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CalculateTransferInstruction']


class CalculateTransferInstruction(BaseDataClass):
    """
    Defines the tradeState or payout on which to create a Transfer along with all necessary resets.
    """
    date: Optional[date] = Field(None, description="")
    payerReceiver: Optional[PayerReceiver] = Field(None, description="")
    payout: AttributeWithReference | Payout = Field(..., description="")
    quantity: Optional[Quantity] = Field(None, description="Specifies quantity amount returned if not the full amount from the TradeState, e.g. partial return")
    """
          Specifies quantity amount returned if not the full amount from the TradeState, e.g. partial return
    """
    resets: Optional[List[Reset]] = Field(None, description="")
    tradeState: TradeState = Field(..., description="")

from cdm.base.staticdata.party.PayerReceiver import PayerReceiver
from cdm.product.template.Payout import Payout
from cdm.base.math.Quantity import Quantity
from cdm.event.common.Reset import Reset
from cdm.event.common.TradeState import TradeState

CalculateTransferInstruction.update_forward_refs()
