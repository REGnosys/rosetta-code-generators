from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['ExecutionTypeEnum']

from enum import Enum

class ExecutionTypeEnum(Enum):
    """
    The enumerated values to specify how a contract has been executed, e.g. electronically, verbally, ...
    """
    ELECTRONIC = "ELECTRONIC"
    """
    Execution via electronic execution facility, derivatives contract market, or other electronic message such as an instant message.
    """
    OFF_FACILITY = "OFF_FACILITY"
    """
    Bilateral execution between counterparties not pursuant to the rules of a SEF or DCM.
    """
