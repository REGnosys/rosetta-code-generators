from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['HaircutIndicatorEnum']

from enum import Enum

class HaircutIndicatorEnum(Enum):
    """
    Represents the enumeration indicators to specify if an asset or group of assets valuation is based on any valuation treatment haircut.
    """
    POST_HAIRCUT = "POST_HAIRCUT"
    """
    Indicates Post haircut value
    """
    PRE_HAIRCUT = "PRE_HAIRCUT"
    """
    Indicates Pre haircut value
    """
