from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['BillingSummary']

from cdm.event.common.RecordAmountTypeEnum import RecordAmountTypeEnum

class BillingSummary(BaseDataClass):
    """
    Specifies individual summaries within a billing invoice.
    """
    summaryAmountType: RecordAmountTypeEnum = Field(..., description="The account level for the billing summary.")
    """
          The account level for the billing summary.
    """
    summaryTransfer: Optional[Transfer] = Field(None, description="The settlement terms for the billing summary")
    """
          The settlement terms for the billing summary
    """

    @cdm_condition
    def condition_0_GrandTotal(self):
        return if_cond(all_elements(self.summaryAmountType, "=", RecordAmountTypeEnum.GrandTotal), '(((self.summaryTransfer) is not None) and ((self.summaryTransfer.payerReceiver) is None))', 'True', self)

    @cdm_condition
    def condition_1_ParentTotal(self):
        return if_cond(all_elements(self.summaryAmountType, "=", RecordAmountTypeEnum.ParentTotal), '((((self.summaryTransfer.payerReceiver) is not None) and ((self.summaryTransfer.payerReceiver.payerAccountReference) is None)) and ((self.summaryTransfer.payerReceiver.receiverAccountReference) is None))', 'True', self)

    @cdm_condition
    def condition_2_AccountTotal(self):
        return if_cond(all_elements(self.summaryAmountType, "=", RecordAmountTypeEnum.AccountTotal), '(((self.summaryTransfer.payerReceiver.payerAccountReference) is not None) and ((self.summaryTransfer.payerReceiver.receiverAccountReference) is not None))', 'True', self)

from cdm.event.common.Transfer import Transfer
from cdm.event.common.RecordAmountTypeEnum import RecordAmountTypeEnum

BillingSummary.update_forward_refs()
