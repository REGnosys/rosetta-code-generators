from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CollateralPosition']

from cdm.event.common.CollateralStatusEnum import CollateralStatusEnum
from cdm.event.position.Position import Position

class CollateralPosition(Position):
    """
    Specifies the individual components of collateral positions.
    """
    collateralPositionStatus: Optional[CollateralStatusEnum] = Field(None, description="Indicates the collateral positions settlement status.")
    """
          Indicates the collateral positions settlement status.
    """
    treatment: Optional[CollateralTreatment] = Field(None, description="Specifies if there is any treatment to be applied to collateral, such as percentage discount which will impact collateral value.")
    """
          Specifies if there is any treatment to be applied to collateral, such as percentage discount which will impact collateral value.
    """

    @cdm_condition
    def condition_0_CollateralPositionStatusSettledOrInTransitOnly(self):
        """
        Represents a condition to ensure that if a status is defined for a collateral position you must only indicate 'Settled Amount' or 'In Transit' amount from the available enumerations.
        """
        return if_cond(((self.collateralPositionStatus) is not None), '(all_elements(self.collateralPositionStatus, "=", CollateralStatusEnum.SettledAmount) or all_elements(self.collateralPositionStatus, "=", CollateralStatusEnum.InTransitAmount))', 'True', self)

from cdm.legaldocumentation.csa.CollateralTreatment import CollateralTreatment
from cdm.event.common.CollateralStatusEnum import CollateralStatusEnum

CollateralPosition.update_forward_refs()
