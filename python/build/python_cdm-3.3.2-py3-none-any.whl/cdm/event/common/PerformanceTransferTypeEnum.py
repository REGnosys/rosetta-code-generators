from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['PerformanceTransferTypeEnum']

from enum import Enum

class PerformanceTransferTypeEnum(Enum):
    """
    The enumerated values to specify the origin of a performance transfer
    """
    COMMODITY = "COMMODITY"
    CORRELATION = "CORRELATION"
    DIVIDEND = "DIVIDEND"
    EQUITY = "EQUITY"
    INTEREST = "INTEREST"
    VARIANCE = "VARIANCE"
    VOLATILITY = "VOLATILITY"
