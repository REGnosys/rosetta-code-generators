from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['TransferState']

from cdm.event.common.TransferStatusEnum import TransferStatusEnum

class TransferState(BaseDataClass):
    """
    Defines the fundamental financial information associated with a Transfer event. Each TransferState specifies where a Transfer is in its life-cycle. TransferState is a root type and as such, can be created independently to any other CDM data type, but can also be used as part of the CDM Event Model.
    """
    transfer: Transfer = Field(..., description="Represents the Transfer that has been effected by a business or life-cycle event.")
    """
          Represents the Transfer that has been effected by a business or life-cycle event.
    """
    transferStatus: Optional[TransferStatusEnum] = Field(None, description="Represents the State of the Transfer through its life-cycle.")
    """
          Represents the State of the Transfer through its life-cycle.
    """

from cdm.event.common.Transfer import Transfer

TransferState.update_forward_refs()
