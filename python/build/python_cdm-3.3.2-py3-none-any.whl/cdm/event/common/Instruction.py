from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['Instruction']


class Instruction(BaseDataClass):
    """
    Instruction to a function that will be used to perform a business event
    """
    before: Optional[AttributeWithReference | TradeState] = Field(None, description="Specifies the trade state that will be acted on by the primitive event functions.")
    """
          Specifies the trade state that will be acted on by the primitive event functions.
    """
    primitiveInstruction: Optional[PrimitiveInstruction] = Field(None, description="Specifies the primitive instructions that will be used to call primitive event functions.")
    """
          Specifies the primitive instructions that will be used to call primitive event functions.
    """

    @cdm_condition
    def condition_0_ExclusiveSplitPrimitive(self):
        """
        A split primitive is exclusive and cannot be combined with other primitives. Instead, the primitive instructions to be applied to each branch of the split must be specified as breakdowns in the split instruction itself.
        """
        return if_cond(((self.primitiveInstruction.split) is not None), 'self.check_one_of_constraint(self, self.primitiveInstruction.split)', 'True', self)

    @cdm_condition
    def condition_1_NewTrade(self):
        """
        There must be no before trade state if the primitive instructions contain an execution, and vice versa. An instruction only handles 1 trade at a time.
        """
        return (if_cond(((self.primitiveInstruction.execution) is not None), '((self.before) is None)', 'True', self) and if_cond(((self.before) is None), '((self.primitiveInstruction.execution) is not None)', 'True', self))

from cdm.event.common.TradeState import TradeState
from cdm.event.common.PrimitiveInstruction import PrimitiveInstruction

Instruction.update_forward_refs()
