from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['BillingSummaryInstruction']

from cdm.event.common.RecordAmountTypeEnum import RecordAmountTypeEnum

class BillingSummaryInstruction(BaseDataClass):
    """
    Specifies the instructions for creation of a billing summary.
    """
    summaryAmountType: RecordAmountTypeEnum = Field(..., description="The account level for the billing summary.")
    """
          The account level for the billing summary.
    """


BillingSummaryInstruction.update_forward_refs()
