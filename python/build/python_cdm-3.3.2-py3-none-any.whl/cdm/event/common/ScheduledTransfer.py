from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['ScheduledTransfer']

from cdm.event.common.CorporateActionTypeEnum import CorporateActionTypeEnum
from cdm.product.common.settlement.ScheduledTransferEnum import ScheduledTransferEnum

class ScheduledTransfer(BaseDataClass):
    corporateActionTransferType: Optional[CorporateActionTypeEnum] = Field(None, description="")
    transferType: ScheduledTransferEnum = Field(..., description="Specifies a transfer created from a scheduled or contingent event on a contract, e.g. Exercise, Performance, Credit Event")
    """
          Specifies a transfer created from a scheduled or contingent event on a contract, e.g. Exercise, Performance, Credit Event
    """

    @cdm_condition
    def condition_0_CorporateActionTransferTypeExists(self):
        """
        When transfer type is Performance or Transfer then the type of event must be specified.
        """
        return if_cond(all_elements(self.transferType, "=", ScheduledTransferEnum.CorporateAction), '((self.corporateActionTransferType) is not None)', 'True', self)

from cdm.product.common.settlement.ScheduledTransferEnum import ScheduledTransferEnum

ScheduledTransfer.update_forward_refs()
