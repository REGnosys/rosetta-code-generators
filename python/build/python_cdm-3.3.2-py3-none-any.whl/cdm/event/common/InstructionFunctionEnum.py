from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['InstructionFunctionEnum']

from enum import Enum

class InstructionFunctionEnum(Enum):
    """
    The enumeration values indicating the BusinessEvent function associated input instructions.
    """
    COMPRESSION = "COMPRESSION"
    CONTRACT_FORMATION = "CONTRACT_FORMATION"
    EXECUTION = "EXECUTION"
    QUANTITY_CHANGE = "QUANTITY_CHANGE"
    RENEGOTIATION = "RENEGOTIATION"
