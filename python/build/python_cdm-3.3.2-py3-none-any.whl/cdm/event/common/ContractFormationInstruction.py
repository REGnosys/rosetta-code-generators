from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['ContractFormationInstruction']


class ContractFormationInstruction(BaseDataClass):
    """
    Specifies instructions to create a fully formed contract, with optional legal agreements.
    """
    legalAgreement: Optional[List[LegalAgreement]] = Field(None, description="Optional legal agreements associated to the contract being formed, for instance a master agreement.")
    """
          Optional legal agreements associated to the contract being formed, for instance a master agreement.
    """

    @cdm_condition
    def condition_0_ExecutedAgreements(self):
        """
        The full formation of a contract can only be completed with executed legal agreements.
        """
        return if_cond(((self.legalAgreement) is not None), '((self.legalAgreement.agreementDate) is not None)', 'True', self)

from cdm.legaldocumentation.common.LegalAgreement import LegalAgreement

ContractFormationInstruction.update_forward_refs()
