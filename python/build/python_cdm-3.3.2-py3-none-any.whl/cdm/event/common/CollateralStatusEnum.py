from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CollateralStatusEnum']

from enum import Enum

class CollateralStatusEnum(Enum):
    """
    Represents the enumeration list to identify the settlement status of the collateral.
    """
    FULL_AMOUNT = "FULL_AMOUNT"
    """
    Indicates the collateral balance amount in full, inclusive of any pre-agreed collateral positions in transit for settlement.
    """
    IN_TRANSIT_AMOUNT = "IN_TRANSIT_AMOUNT"
    """
    Indicates collateral amount in transit settlement cycle only, excluding settled collateral amount/s.
    """
    SETTLED_AMOUNT = "SETTLED_AMOUNT"
    """
    Indicates the collateral is settled and not an in transit pre-agreed collateral amount/s.
    """
