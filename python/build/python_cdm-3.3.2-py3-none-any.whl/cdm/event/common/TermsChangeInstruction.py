from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['TermsChangeInstruction']

from cdm.product.common.NotionalAdjustmentEnum import NotionalAdjustmentEnum

class TermsChangeInstruction(BaseDataClass):
    """
    Specifies instructions for terms change consisting of the new transaction terms, and the renegotiation fee.
    """
    adjustment: Optional[NotionalAdjustmentEnum] = Field(None, description="")
    ancillaryParty: Optional[List[AncillaryParty]] = Field(None, description="ancillary party to be changed")
    """
          ancillary party to be changed
    """
    product: Optional[Product] = Field(None, description="product to be changed")
    """
          product to be changed
    """

    @cdm_condition
    def condition_0_AtLeastOneOf(self):
        return ((((self.product) is not None) or ((self.ancillaryParty) is not None)) or ((self.adjustment) is not None))

from cdm.base.staticdata.party.AncillaryParty import AncillaryParty
from cdm.product.template.Product import Product

TermsChangeInstruction.update_forward_refs()
