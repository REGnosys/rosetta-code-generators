from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['AffirmationStatusEnum']

from enum import Enum

class AffirmationStatusEnum(Enum):
    """
    Enumeration for the different types of affirmation status.
    """
    AFFIRMED = "AFFIRMED"
    UNAFFIRMED = "UNAFFIRMED"
