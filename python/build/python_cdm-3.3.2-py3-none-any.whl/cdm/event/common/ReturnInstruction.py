from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['ReturnInstruction']


class ReturnInstruction(BaseDataClass):
    """
    Specifies the information required to create the return of a Security Finance Transaction.
    """
    quantity: List[Quantity] = Field(None, description="Specifies the quantity of shares and cash to be returned in a partial return event.")
    """
          Specifies the quantity of shares and cash to be returned in a partial return event.
    """
    @cdm_condition
    def cardinality_quantity(self):
        return check_cardinality(self.quantity, 1, None)


from cdm.base.math.Quantity import Quantity

ReturnInstruction.update_forward_refs()
