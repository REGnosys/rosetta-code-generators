from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['AssetTransferTypeEnum']

from enum import Enum

class AssetTransferTypeEnum(Enum):
    """
    The qualification of the type of asset transfer.
    """
    FREE_OF_PAYMENT = "FREE_OF_PAYMENT"
    """
    The transfer of assets takes place without a corresponding exchange of payment.
    """
