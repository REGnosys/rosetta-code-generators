from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['MarginCallResponseAction']

from cdm.event.common.MarginCallActionEnum import MarginCallActionEnum

class MarginCallResponseAction(BaseDataClass):
    """
    Specifies the margin call action details, including collateral to be moved and its direction.
    """
    collateralPositionComponent: List[CollateralPosition] = Field(None, description="Specifies the collateral to be moved and its direction.")
    """
          Specifies the collateral to be moved and its direction.
    """
    @cdm_condition
    def cardinality_collateralPositionComponent(self):
        return check_cardinality(self.collateralPositionComponent, 1, None)

    marginCallAction: MarginCallActionEnum = Field(..., description="Specifies the margin call action details, specified as either Delivery or Return.")
    """
          Specifies the margin call action details, specified as either Delivery or Return.
    """

from cdm.event.common.CollateralPosition import CollateralPosition

MarginCallResponseAction.update_forward_refs()
