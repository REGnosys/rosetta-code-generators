from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['RegMarginTypeEnum']

from enum import Enum

class RegMarginTypeEnum(Enum):
    """
    Represents the enumeration values to specify the margin type in relation to bilateral or regulatory obligation.
    """
    NON_REG_IM = "NON_REG_IM"
    """
    Indicates Non Regulatory Initial margin or independent amount
    """
    REG_IM = "REG_IM"
    """
    Indicates Regulatory Initial Margin
    """
    VM = "VM"
    """
    Indicates Variation Margin
    """
