from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CallTypeEnum']

from enum import Enum

class CallTypeEnum(Enum):
    """
    Represents the enumeration values that indicate the intended status of message type, such as expected call, notification of a call or a margin call.
    """
    EXPECTED_CALL = "EXPECTED_CALL"
    """
    Identifies an expected Margin Call instruction for either party to notify the other or their service provider of an expected margin call movement.
    """
    MARGIN_CALL = "MARGIN_CALL"
    """
    Identifies an actionable Margin Call.
    """
    NOTIFICATION = "NOTIFICATION"
    """
    Identifies a notification of a Margin Call for legal obligation to notify other party to initiate a margin call when notifying party is calculation or valuation agent.
    """
