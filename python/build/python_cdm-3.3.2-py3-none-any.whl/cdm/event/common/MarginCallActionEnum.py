from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['MarginCallActionEnum']

from enum import Enum

class MarginCallActionEnum(Enum):
    """
    Represents the enumeration values to identify the collateral action instruction.
    """
    DELIVERY = "DELIVERY"
    """
    Indicates an instruction of a new collateral asset delivery.
    """
    RETURN = "RETURN"
    """
    Indicates an instruction for a return of a principals collateral asset delivery.
    """
