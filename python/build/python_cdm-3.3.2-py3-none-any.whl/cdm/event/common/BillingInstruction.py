from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['BillingInstruction']


class BillingInstruction(BaseDataClass):
    """
    Specifies the instructions for creation of a Security Lending billing invoice.
    """
    billingEndDate: date = Field(..., description="The ending date of the period described by this invoice")
    """
          The ending date of the period described by this invoice
    """
    billingRecordInstruction: List[BillingRecordInstruction] = Field(None, description="Instructions for creating the billing records contained within the invoice")
    """
          Instructions for creating the billing records contained within the invoice
    """
    @cdm_condition
    def cardinality_billingRecordInstruction(self):
        return check_cardinality(self.billingRecordInstruction, 1, None)

    billingStartDate: date = Field(..., description="The starting date of the period described by this invoice")
    """
          The starting date of the period described by this invoice
    """
    billingSummary: Optional[List[BillingSummaryInstruction]] = Field(None, description="The billing summaries contained within the invoice")
    """
          The billing summaries contained within the invoice
    """
    receivingParty: Party = Field(..., description="The party receiving the invoice")
    """
          The party receiving the invoice
    """
    sendingParty: Party = Field(..., description="The party issuing the invoice")
    """
          The party issuing the invoice
    """

from cdm.event.common.BillingRecordInstruction import BillingRecordInstruction
from cdm.event.common.BillingSummaryInstruction import BillingSummaryInstruction
from cdm.base.staticdata.party.Party import Party

BillingInstruction.update_forward_refs()
