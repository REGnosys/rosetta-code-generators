from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['EventInstruction']

from cdm.event.common.EventIntentEnum import EventIntentEnum

class EventInstruction(BaseDataClass):
    """
    Specifies instructions to create a BusinessEvent.
    """
    effectiveDate: Optional[date] = Field(None, description="The date on which the event contractually takes effect, when different from the event date.")
    """
          The date on which the event contractually takes effect, when different from the event date.
    """
    eventDate: Optional[date] = Field(None, description="The date of the business event.")
    """
          The date of the business event.
    """
    instruction: Optional[List[Instruction]] = Field(None, description="The instructions for creation of a business event.")
    """
          The instructions for creation of a business event.
    """
    intent: Optional[EventIntentEnum] = Field(None, description="The event intent.")
    """
          The event intent.
    """

from cdm.event.common.Instruction import Instruction

EventInstruction.update_forward_refs()
