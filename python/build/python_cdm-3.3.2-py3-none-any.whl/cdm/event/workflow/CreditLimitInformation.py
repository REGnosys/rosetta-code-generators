from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CreditLimitInformation']


class CreditLimitInformation(BaseDataClass):
    """
    A class to represent the credit limit utilisation information.
    """
    limitApplicable: List[LimitApplicableExtended] = Field(None, description="")
    @cdm_condition
    def cardinality_limitApplicable(self):
        return check_cardinality(self.limitApplicable, 1, None)


from cdm.event.workflow.LimitApplicableExtended import LimitApplicableExtended

CreditLimitInformation.update_forward_refs()
