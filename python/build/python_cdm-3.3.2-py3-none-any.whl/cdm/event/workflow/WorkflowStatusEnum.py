from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['WorkflowStatusEnum']

from enum import Enum

class WorkflowStatusEnum(Enum):
    ACCEPTED = "ACCEPTED"
    AFFIRMED = "AFFIRMED"
    ALLEGED = "ALLEGED"
    AMENDED = "AMENDED"
    CANCELLED = "CANCELLED"
    CERTAIN = "CERTAIN"
    CLEARED = "CLEARED"
    CONFIRMED = "CONFIRMED"
    PENDING = "PENDING"
    REJECTED = "REJECTED"
    SUBMITTED = "SUBMITTED"
    TERMINATED = "TERMINATED"
    UNCERTAIN = "UNCERTAIN"
    UNCONFIRMED = "UNCONFIRMED"
