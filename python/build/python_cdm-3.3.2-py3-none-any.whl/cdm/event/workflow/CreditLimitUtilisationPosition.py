from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CreditLimitUtilisationPosition']


class CreditLimitUtilisationPosition(BaseDataClass):
    _global: Optional[float] = Field(None, description="Global credit limit utilisation amount, agnostic of long/short position direction.")
    """
          Global credit limit utilisation amount, agnostic of long/short position direction.
    """
    longPosition: Optional[float] = Field(None, description="Credit limit utilisation attributable to long positions.")
    """
          Credit limit utilisation attributable to long positions.
    """
    shortPosition: Optional[float] = Field(None, description="Credit limit utilisation attributable to short positions.")
    """
          Credit limit utilisation attributable to short positions.
    """


CreditLimitUtilisationPosition.update_forward_refs()
