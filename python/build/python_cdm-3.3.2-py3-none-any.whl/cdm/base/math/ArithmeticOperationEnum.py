from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['ArithmeticOperationEnum']

from enum import Enum

class ArithmeticOperationEnum(Enum):
    """
    An arithmetic operator that can be passed to a function
    """
    ADD = "ADD"
    """
    Addition
    """
    DIVIDE = "DIVIDE"
    """
    Division
    """
    MAX = "MAX"
    """
    Max of 2 values
    """
    MIN = "MIN"
    """
    Min of 2 values
    """
    MULTIPLY = "MULTIPLY"
    """
    Multiplication
    """
    SUBTRACT = "SUBTRACT"
    """
    Subtraction
    """
