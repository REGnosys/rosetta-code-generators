from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['WeatherUnitEnum']

from enum import Enum

class WeatherUnitEnum(Enum):
    """
    Provides enumerated values for weather units, generally used in the context of defining quantities for commodities.
    """
    CDD = "CDD"
    """
    Denotes Cooling Degree Days as a standard unit.
    """
    CPD = "CPD"
    """
    Denotes Critical Precipitation Day as a standard unit.
    """
    HDD = "HDD"
    """
    Heating Degree Day as a standard unit.
    """
