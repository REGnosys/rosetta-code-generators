from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['Rounding']

from cdm.base.math.RoundingDirectionEnum import RoundingDirectionEnum

class Rounding(BaseDataClass):
    """
    Defines rounding rules and precision to be used in the rounding of a number.
    """
    precision: Optional[int] = Field(None, description="Specifies the rounding precision in terms of a number of decimal places when the number is evaluated in decimal form (not percentage), e.g. 0.09876543 rounded to the nearest 5 decimal places is  0.0987654.")
    """
          Specifies the rounding precision in terms of a number of decimal places when the number is evaluated in decimal form (not percentage), e.g. 0.09876543 rounded to the nearest 5 decimal places is  0.0987654.
    """
    roundingDirection: RoundingDirectionEnum = Field(..., description="Specifies the rounding rounding rule as up, down, or nearest.")
    """
          Specifies the rounding rounding rule as up, down, or nearest.
    """


Rounding.update_forward_refs()
