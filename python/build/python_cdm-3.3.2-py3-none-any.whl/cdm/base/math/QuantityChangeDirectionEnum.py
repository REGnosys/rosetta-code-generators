from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['QuantityChangeDirectionEnum']

from enum import Enum

class QuantityChangeDirectionEnum(Enum):
    """
    Specifies whether a quantity change is an increase, a decrease or a replacement, whereby the quantity is always specified as a positive number.
    """
    DECREASE = "DECREASE"
    """
    When the quantity should go down by the specified amount.
    """
    INCREASE = "INCREASE"
    """
    When the quantity should go up by the specified amount.
    """
    REPLACE = "REPLACE"
    """
    When the quantity should be replaced by the specified amount.
    """
