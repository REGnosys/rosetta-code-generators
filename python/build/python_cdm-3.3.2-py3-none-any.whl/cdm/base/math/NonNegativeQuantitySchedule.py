from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['NonNegativeQuantitySchedule']

from cdm.base.math.QuantitySchedule import QuantitySchedule

class NonNegativeQuantitySchedule(QuantitySchedule):

    @cdm_condition
    def condition_0_NonNegativeQuantity_amount(self):
        """
        For a non-negative quantity, all amount attribute must be positive.
        """
        return if_cond(((self.value) is not None), '(all_elements(self.value, ">=", 0.0) and if_cond(((self.datedValue) is not None), \'all_elements(self.datedValue.value, ">=", 0.0)\', \'True\', self))', 'True', self)


NonNegativeQuantitySchedule.update_forward_refs()
