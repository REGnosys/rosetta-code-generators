from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['AveragingCalculationMethod']

from cdm.base.math.AveragingCalculationMethodEnum import AveragingCalculationMethodEnum

class AveragingCalculationMethod(BaseDataClass):
    """
    Defines the ways in which multiple values can be aggregated into a single value.
    """
    calculationMethod: AveragingCalculationMethodEnum = Field(..., description="Identifies which of the Pythagorean means is being used to compute an average value.")
    """
          Identifies which of the Pythagorean means is being used to compute an average value.
    """
    isWeighted: bool = Field(..., description="Identifies whether the average values will be weighted or unweighted.")
    """
          Identifies whether the average values will be weighted or unweighted.
    """


AveragingCalculationMethod.update_forward_refs()
