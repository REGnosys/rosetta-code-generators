from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['UnitType']

from cdm.base.math.CapacityUnitEnum import CapacityUnitEnum
from cdm.base.math.FinancialUnitEnum import FinancialUnitEnum
from cdm.base.math.WeatherUnitEnum import WeatherUnitEnum

class UnitType(BaseDataClass):
    """
    Defines the unit to be used for price, quantity, or other purposes
    """
    capacityUnit: Optional[CapacityUnitEnum] = Field(None, description="Provides an enumerated value for a capacity unit, generally used in the context of defining quantities for commodities.")
    """
          Provides an enumerated value for a capacity unit, generally used in the context of defining quantities for commodities.
    """
    currency: Optional[AttributeWithMeta[str] | str] = Field(None, description="Defines the currency to be used as a unit for a price, quantity, or other purpose.")
    """
          Defines the currency to be used as a unit for a price, quantity, or other purpose.
    """
    financialUnit: Optional[FinancialUnitEnum] = Field(None, description="Provides an enumerated value for financial units, generally used in the context of defining quantities for securities.")
    """
          Provides an enumerated value for financial units, generally used in the context of defining quantities for securities.
    """
    weatherUnit: Optional[WeatherUnitEnum] = Field(None, description="Provides an enumerated values for a weather unit, generally used in the context of defining quantities for commodities.")
    """
          Provides an enumerated values for a weather unit, generally used in the context of defining quantities for commodities.
    """

    @cdm_condition
    def condition_0_UnitType(self):
        """
        Requires that a unit type must be set.
        """
        return self.check_one_of_constraint('capacityUnit', 'weatherUnit', 'financialUnit', 'currency', necessity=True)


UnitType.update_forward_refs()
