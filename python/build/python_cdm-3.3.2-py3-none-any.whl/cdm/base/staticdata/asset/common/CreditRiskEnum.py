from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CreditRiskEnum']

from enum import Enum

class CreditRiskEnum(Enum):
    """
    Represents an enumeration list to identify tranched or untranched credit risk.
    """
    TRANCHED_CREDIT_RISK = "TRANCHED_CREDIT_RISK"
    """
    Indicates tranched credit risk, including securitizations.
    """
    UNTRANCHED_CREDIT_RISK = "UNTRANCHED_CREDIT_RISK"
    """
    Indicates tranched credit risk, including repackagings.
    """
