from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['SpecialPurposeVehicleIssuerType']

from cdm.base.staticdata.asset.common.CreditRiskEnum import CreditRiskEnum

class SpecialPurposeVehicleIssuerType(BaseDataClass):
    """
    Represents a class to allow specification of different types of special purpose vehicle (SPV) collateral.
    """
    creditRisk: Optional[CreditRiskEnum] = Field(None, description="Indicates tranched or untranched credit risk.")
    """
          Indicates tranched or untranched credit risk.
    """


SpecialPurposeVehicleIssuerType.update_forward_refs()
