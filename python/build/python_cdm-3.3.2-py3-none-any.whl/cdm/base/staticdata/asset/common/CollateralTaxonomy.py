from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CollateralTaxonomy']

from cdm.base.staticdata.asset.common.TaxonomySourceEnum import TaxonomySourceEnum

class CollateralTaxonomy(BaseDataClass):
    """
    Specifies the collateral taxonomy, which is composed of a taxonomy value and a taxonomy source.
    """
    taxonomySource: TaxonomySourceEnum = Field(..., description="Specifies the taxonomy source.")
    """
          Specifies the taxonomy source.
    """
    taxonomyValue: CollateralTaxonomyValue = Field(..., description="Specifies the taxonomy value.")
    """
          Specifies the taxonomy value.
    """

    @cdm_condition
    def condition_0_Eu_EligibleCollateralTaxonomy(self):
        """
        If the Taxonomy Source is specified as EU EMIR Eligible Collateral then the enumeration must be EU EMIR Eligible Collateral.
        """
        return if_cond(all_elements(self.taxonomySource, "=", TaxonomySourceEnum.EU_EMIR_EligibleCollateralAssetClass), '((self.taxonomyValue.eu_EMIR_EligibleCollateral) is not None)', 'True', self)

    @cdm_condition
    def condition_1_UkEligibleCollateralTaxonomy(self):
        """
        If the Taxonomy Source is specified as UK EMIR Eligible Collateral then the enumeration must be UK EMIR Eligible Collateral.
        """
        return if_cond(all_elements(self.taxonomySource, "=", TaxonomySourceEnum.UK_EMIR_EligibleCollateralAssetClass), '((self.taxonomyValue.uk_EMIR_EligibleCollateral) is not None)', 'True', self)

    @cdm_condition
    def condition_2_UsEligibleCollateralTaxonomy(self):
        """
        If the Taxonomy Source is specified as US CFTCPR Eligbile Collateral then the enumeration must be US CFTCPR Eligible Collateral.
        """
        return if_cond(all_elements(self.taxonomySource, "=", TaxonomySourceEnum.US_CFTC_PR_EligibleCollateralAssetClass), '((self.taxonomyValue.us_CFTC_PR_EligibleCollateral) is not None)', 'True', self)

    @cdm_condition
    def condition_3_TaxonomyValue(self):
        """
        If the Taxonomy Value is specified as a string then the taxonomy Source cannot be either EU Eligible Collateral or Uk Eligible Collateral or US Eligible Collateral.
        """
        return if_cond(((self.taxonomyValue.nonEnumeratedTaxonomyValue) is not None), '((any_elements(self.taxonomySource, "<>", TaxonomySourceEnum.EU_EMIR_EligibleCollateralAssetClass) and any_elements(self.taxonomySource, "<>", TaxonomySourceEnum.UK_EMIR_EligibleCollateralAssetClass)) and any_elements(self.taxonomySource, "<>", TaxonomySourceEnum.US_CFTC_PR_EligibleCollateralAssetClass))', 'True', self)

from cdm.base.staticdata.asset.common.CollateralTaxonomyValue import CollateralTaxonomyValue
from cdm.base.staticdata.asset.common.TaxonomySourceEnum import TaxonomySourceEnum

CollateralTaxonomy.update_forward_refs()
