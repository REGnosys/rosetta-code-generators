from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['SupraNationalIssuerTypeEnum']

from enum import Enum

class SupraNationalIssuerTypeEnum(Enum):
    """
    Represents an enumeration list to identify the type of supranational entity issuing the asset.
    """
    INTERNATIONAL_ORGANISATION = "INTERNATIONAL_ORGANISATION"
    """
    Specifies International Financial Institution.
    """
    MULTILATERAL_BANK = "MULTILATERAL_BANK"
    """
    Specifies Multilateral Bank or Multilateral Development Bank.
    """
