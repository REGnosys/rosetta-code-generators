from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CollateralIssuerType']

from cdm.base.staticdata.asset.common.IssuerTypeEnum import IssuerTypeEnum
from cdm.base.staticdata.asset.common.SupraNationalIssuerTypeEnum import SupraNationalIssuerTypeEnum

class CollateralIssuerType(BaseDataClass):
    """
    Represents a class to allow specification of the type of entity issuing the collateral.
    """
    issuerType: IssuerTypeEnum = Field(..., description="Specifies the origin of entity issuing the collateral.")
    """
          Specifies the origin of entity issuing the collateral.
    """
    quasiGovernmentType: Optional[QuasiGovernmentIssuerType] = Field(None, description="Specifies debt issues by institutions or bodies, typically constituted by statute, with a function mandated by the government and subject to government supervision inclusive of profit- and non-profit making bodies. Includes the US Agencies and GSEs and the EU concept of public sector entities. Excluding any entities which are also Regional Government.")
    """
          Specifies debt issues by institutions or bodies, typically constituted by statute, with a function mandated by the government and subject to government supervision inclusive of profit- and non-profit making bodies. Includes the US Agencies and GSEs and the EU concept of public sector entities. Excluding any entities which are also Regional Government.
    """
    regionalGovernmentType: Optional[RegionalGovernmentIssuerType] = Field(None, description="Specifies Regional government, local authority or municipal.")
    """
          Specifies Regional government, local authority or municipal.
    """
    specialPurposeVehicleType: Optional[SpecialPurposeVehicleIssuerType] = Field(None, description="Specifies a subsidiary company that is formed to undertake a specific business purpose of acquisition and financing of specific assets on a potentially limited recourse basis dependent of how it is designed. E.g. asset backed securities, including securitisations.")
    """
          Specifies a subsidiary company that is formed to undertake a specific business purpose of acquisition and financing of specific assets on a potentially limited recourse basis dependent of how it is designed. E.g. asset backed securities, including securitisations.
    """
    supraNationalType: Optional[SupraNationalIssuerTypeEnum] = Field(None, description="Specifies debt issued by international organisations and multilateral banks.")
    """
          Specifies debt issued by international organisations and multilateral banks.
    """

    @cdm_condition
    def condition_0_SupraNationalSubType(self):
        return if_cond(any_elements(self.issuerType, "<>", IssuerTypeEnum.SupraNational), '((self.supraNationalType) is None)', 'True', self)

    @cdm_condition
    def condition_1_QuasiGovernmentSubType(self):
        return if_cond(any_elements(self.issuerType, "<>", IssuerTypeEnum.QuasiGovernment), '((self.quasiGovernmentType) is None)', 'True', self)

    @cdm_condition
    def condition_2_RegionalGovernmentSubType(self):
        return if_cond(any_elements(self.issuerType, "<>", IssuerTypeEnum.RegionalGovernment), '((self.regionalGovernmentType) is None)', 'True', self)

    @cdm_condition
    def condition_3_SpecialPurposeVehicleSubType(self):
        return if_cond(any_elements(self.issuerType, "<>", IssuerTypeEnum.SpecialPurposeVehicle), '((self.specialPurposeVehicleType) is None)', 'True', self)

from cdm.base.staticdata.asset.common.QuasiGovernmentIssuerType import QuasiGovernmentIssuerType
from cdm.base.staticdata.asset.common.RegionalGovernmentIssuerType import RegionalGovernmentIssuerType
from cdm.base.staticdata.asset.common.SpecialPurposeVehicleIssuerType import SpecialPurposeVehicleIssuerType
from cdm.base.staticdata.asset.common.IssuerTypeEnum import IssuerTypeEnum

CollateralIssuerType.update_forward_refs()
