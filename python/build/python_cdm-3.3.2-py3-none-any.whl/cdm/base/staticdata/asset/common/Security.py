from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['Security']

from cdm.base.staticdata.asset.common.EquityTypeEnum import EquityTypeEnum
from cdm.base.staticdata.asset.common.FundProductTypeEnum import FundProductTypeEnum
from cdm.base.staticdata.asset.common.SecurityTypeEnum import SecurityTypeEnum
from cdm.base.staticdata.asset.common.ProductBase import ProductBase

class Security(ProductBase):
    """
    Identifies a security by referencing a product identifier and by specifying the sector.
    """
    debtType: Optional[DebtType] = Field(None, description="Identifies the type of debt and selected debt economics.")
    """
          Identifies the type of debt and selected debt economics.
    """
    economicTerms: Optional[EconomicTerms] = Field(None, description="The economic terms associated with a contractual product, i.e. the set of features that are price-forming.")
    """
          The economic terms associated with a contractual product, i.e. the set of features that are price-forming.
    """
    equityType: Optional[EquityTypeEnum] = Field(None, description="Identifies the type of equity.")
    """
          Identifies the type of equity.
    """
    fundType: Optional[FundProductTypeEnum] = Field(None, description="Identifies the type of fund.")
    """
          Identifies the type of fund.
    """
    securityType: SecurityTypeEnum = Field(..., description="Identifies the type of security using an enumerated list.")
    """
          Identifies the type of security using an enumerated list.
    """

    @cdm_condition
    def condition_0_DebtSubType(self):
        return if_cond(any_elements(self.securityType, "<>", SecurityTypeEnum.Debt), '((self.debtType) is None)', 'True', self)

    @cdm_condition
    def condition_1_EquitySubType(self):
        return if_cond(any_elements(self.securityType, "<>", SecurityTypeEnum.Equity), '((self.equityType) is None)', 'True', self)

    @cdm_condition
    def condition_2_FundSubType(self):
        return if_cond(any_elements(self.securityType, "<>", SecurityTypeEnum.Fund), '((self.fundType) is None)', 'True', self)

    @cdm_condition
    def condition_3_BondEconomicTerms(self):
        return if_cond(((self.economicTerms) is not None), 'all_elements(self.securityType, "=", SecurityTypeEnum.Debt)', 'True', self)

from cdm.base.staticdata.asset.common.DebtType import DebtType
from cdm.product.template.EconomicTerms import EconomicTerms
from cdm.base.staticdata.asset.common.SecurityTypeEnum import SecurityTypeEnum

Security.update_forward_refs()
