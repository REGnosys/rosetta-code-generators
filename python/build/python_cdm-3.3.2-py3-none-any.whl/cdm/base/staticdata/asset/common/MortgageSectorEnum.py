from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['MortgageSectorEnum']

from enum import Enum

class MortgageSectorEnum(Enum):
    """
    The enumerated values to specify a mortgage typology.
    """
    ABS = "ABS"
    """
    Asset Backed Security.
    """
    CDO = "CDO"
    """
    Collateralized Debt Obligation.
    """
    CMBS = "CMBS"
    """
    Commercial Mortgage Backed Security.
    """
    RMBS = "RMBS"
    """
    Residential Mortgage Backed Security.
    """
