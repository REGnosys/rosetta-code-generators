from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['DebtType']

from cdm.base.staticdata.asset.common.DebtClassEnum import DebtClassEnum

class DebtType(BaseDataClass):
    """
    Specifies the type of debt instrument.
    """
    debtClass: Optional[DebtClassEnum] = Field(None, description="Specifies the characteristics of a debt instrument.")
    """
          Specifies the characteristics of a debt instrument.
    """
    debtEconomics: Optional[List[DebtEconomics]] = Field(None, description="Specifies selected financial terms of a debt instrument.")
    """
          Specifies selected financial terms of a debt instrument.
    """

from cdm.base.staticdata.asset.common.DebtEconomics import DebtEconomics

DebtType.update_forward_refs()
