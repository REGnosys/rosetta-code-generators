from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['AssetType']

from cdm.base.staticdata.asset.common.AssetTypeEnum import AssetTypeEnum
from cdm.base.staticdata.asset.common.EquityTypeEnum import EquityTypeEnum
from cdm.base.staticdata.asset.common.FundProductTypeEnum import FundProductTypeEnum
from cdm.base.staticdata.asset.common.SecurityTypeEnum import SecurityTypeEnum

class AssetType(BaseDataClass):
    """
    Represents a class to allow specification of the asset product type.
    """
    assetType: AssetTypeEnum = Field(..., description="Represents a filter based on the type of collateral asset.")
    """
          Represents a filter based on the type of collateral asset.
    """
    debtType: Optional[DebtType] = Field(None, description="Represents a filter based on the type of bond.")
    """
          Represents a filter based on the type of bond.
    """
    equityType: Optional[EquityTypeEnum] = Field(None, description="Represents a filter based on the type of equity.")
    """
          Represents a filter based on the type of equity.
    """
    fundType: Optional[FundProductTypeEnum] = Field(None, description="Represents a filter based on the type of fund.")
    """
          Represents a filter based on the type of fund.
    """
    otherAssetType: Optional[List[str]] = Field(None, description="Specifies the eligible asset type when not enumerated.")
    """
          Specifies the eligible asset type when not enumerated.
    """
    securityType: Optional[SecurityTypeEnum] = Field(None, description="Represents a filter based on the type of security.")
    """
          Represents a filter based on the type of security.
    """

    @cdm_condition
    def condition_0_SecuritySubType(self):
        return if_cond(any_elements(self.assetType, "<>", AssetTypeEnum.Security), '((((self.securityType) is None) and ((self.debtType) is None)) and ((self.equityType) is None))', 'True', self)

    @cdm_condition
    def condition_1_BondSubType(self):
        return if_cond(any_elements(self.securityType, "<>", SecurityTypeEnum.Debt), '((self.debtType) is None)', 'True', self)

    @cdm_condition
    def condition_2_EquitySubType(self):
        return if_cond(any_elements(self.securityType, "<>", SecurityTypeEnum.Equity), '((self.equityType) is None)', 'True', self)

    @cdm_condition
    def condition_3_FundSubType(self):
        return if_cond(any_elements(self.securityType, "<>", SecurityTypeEnum.Fund), '((self.fundType) is None)', 'True', self)

    @cdm_condition
    def condition_4_OtherAssetSubType(self):
        return if_cond(all_elements(self.assetType, "=", AssetTypeEnum.Other), '((self.otherAssetType) is not None)', 'True', self)

from cdm.base.staticdata.asset.common.DebtType import DebtType
from cdm.base.staticdata.asset.common.AssetTypeEnum import AssetTypeEnum
from cdm.base.staticdata.asset.common.SecurityTypeEnum import SecurityTypeEnum

AssetType.update_forward_refs()
