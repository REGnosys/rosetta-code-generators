from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['MaturityTypeEnum']

from enum import Enum

class MaturityTypeEnum(Enum):
    """
    Represents an enumeration list to identify the Maturity.
    """
    FROM_ISSUANCE = "FROM_ISSUANCE"
    """
    Denotes a period from issuance date until now.
    """
    ORIGINAL_MATURITY = "ORIGINAL_MATURITY"
    """
    Denotes a period from issuance until maturity date.
    """
    REMAINING_MATURITY = "REMAINING_MATURITY"
    """
    Denotes a period from now until maturity date.
    """
