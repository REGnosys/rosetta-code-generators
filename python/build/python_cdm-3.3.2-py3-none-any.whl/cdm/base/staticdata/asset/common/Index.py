from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['Index']

from cdm.base.staticdata.asset.common.ProductBase import ProductBase

class Index(ProductBase):
    """
    Identifies an index by referencing a product identifier.
    """
    pass


Index.update_forward_refs()
