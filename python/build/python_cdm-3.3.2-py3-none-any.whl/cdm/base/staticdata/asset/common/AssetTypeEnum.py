from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['AssetTypeEnum']

from enum import Enum

class AssetTypeEnum(Enum):
    """
    Represents an enumeration list to identify the asset type.
    """
    CASH = "CASH"
    """
    Indentifies cash in a currency form.
    """
    COMMODITY = "COMMODITY"
    """
    Indentifies basic good used in commerce that is interchangeable with other goods of the same type.
    """
    OTHER = "OTHER"
    """
    Indentifies other asset types.
    """
    SECURITY = "SECURITY"
    """
    Indentifies negotiable financial instrument of monetary value with an issue ownership position.
    """
