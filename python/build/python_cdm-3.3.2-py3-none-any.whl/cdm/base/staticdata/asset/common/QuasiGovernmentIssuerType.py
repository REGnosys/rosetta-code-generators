from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['QuasiGovernmentIssuerType']


class QuasiGovernmentIssuerType(BaseDataClass):
    """
    Represents a class to allow specification of different types of Quasi Government collateral.
    """
    sovereignEntity: bool = Field(..., description="True if sovereign entity (e.g. not separate legal personality from sovereign) or false if non-sovereign entity (e.g. separate legal personality from sovereign).")
    """
          True if sovereign entity (e.g. not separate legal personality from sovereign) or false if non-sovereign entity (e.g. separate legal personality from sovereign).
    """
    sovereignRecourse: Optional[bool] = Field(None, description="Applies to non-sovereign entity (e.g. separate legal personality from sovereign).  True if entity has recourse to sovereign (e.g. debt guaranteed by government).  False if entity does not have recourse to sovereign.")
    """
          Applies to non-sovereign entity (e.g. separate legal personality from sovereign).  True if entity has recourse to sovereign (e.g. debt guaranteed by government).  False if entity does not have recourse to sovereign.
    """

    @cdm_condition
    def condition_0_NonSovereignEntityRecourse(self):
        return if_cond(((self.sovereignRecourse) is not None), 'all_elements(self.sovereignEntity, "=", False)', 'True', self)


QuasiGovernmentIssuerType.update_forward_refs()
