from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['ObligationCategoryEnum']

from enum import Enum

class ObligationCategoryEnum(Enum):
    """
    The enumerated values used in both the obligations and deliverable obligations of the credit default swap to represent a class or type of securities which apply.
    """
    BOND = "BOND"
    """
    ISDA term 'Bond'.
    """
    BOND_OR_LOAN = "BOND_OR_LOAN"
    """
    ISDA term 'Bond or Loan'.
    """
    BORROWED_MONEY = "BORROWED_MONEY"
    """
    ISDA term 'Borrowed Money'.
    """
    LOAN = "LOAN"
    """
    ISDA term 'Loan'.
    """
    PAYMENT = "PAYMENT"
    """
    ISDA term 'Payment'.
    """
    REFERENCE_OBLIGATIONS_ONLY = "REFERENCE_OBLIGATIONS_ONLY"
    """
    ISDA term 'Reference Obligations Only'.
    """
