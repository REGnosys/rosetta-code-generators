from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CounterpartyRoleEnum']

from enum import Enum

class CounterpartyRoleEnum(Enum):
    """
    Defines the enumerated values to specify the two counterparties to the transaction.
    """
    PARTY_1 = "PARTY_1"
    PARTY_2 = "PARTY_2"
