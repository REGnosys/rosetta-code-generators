from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['ContactInformation']


class ContactInformation(BaseDataClass):
    """
    A class to specify contact information associated with a party: telephone, postal/street address, email and web page.
    """
    address: Optional[List[Address]] = Field(None, description="The street/postal address.")
    """
          The street/postal address.
    """
    email: Optional[List[str]] = Field(None, description="The email address.")
    """
          The email address.
    """
    telephone: Optional[List[TelephoneNumber]] = Field(None, description="The telephone number.")
    """
          The telephone number.
    """
    webPage: Optional[List[str]] = Field(None, description="The web page. This attribute is not specified as part of the FpML ContactInformation complex type.")
    """
          The web page. This attribute is not specified as part of the FpML ContactInformation complex type.
    """

from cdm.base.staticdata.party.Address import Address
from cdm.base.staticdata.party.TelephoneNumber import TelephoneNumber

ContactInformation.update_forward_refs()
