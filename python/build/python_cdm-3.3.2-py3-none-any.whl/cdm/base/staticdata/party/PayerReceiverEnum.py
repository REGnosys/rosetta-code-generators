from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['PayerReceiverEnum']

from enum import Enum

class PayerReceiverEnum(Enum):
    """
    The enumerated values to specify an interest rate stream payer or receiver party.
    """
    PAYER = "PAYER"
    """
    The party identified as the stream payer.
    """
    RECEIVER = "RECEIVER"
    """
    The party identified as the stream receiver.
    """
