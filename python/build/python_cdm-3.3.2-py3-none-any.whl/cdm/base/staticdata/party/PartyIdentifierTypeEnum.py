from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['PartyIdentifierTypeEnum']

from enum import Enum

class PartyIdentifierTypeEnum(Enum):
    """
    The enumeration values associated with party identifier sources.
    """
    BIC = "BIC"
    """
    The Bank Identifier Code.
    """
    LEI = "LEI"
    """
    The ISO 17442:2012 Legal Entity Identifier.
    """
    MIC = "MIC"
    """
    The ISO 10383 Market Identifier Code (MIC).
    """
