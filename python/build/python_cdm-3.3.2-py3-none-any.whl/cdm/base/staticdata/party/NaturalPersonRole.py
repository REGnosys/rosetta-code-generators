from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['NaturalPersonRole']

from cdm.base.staticdata.party.NaturalPersonRoleEnum import NaturalPersonRoleEnum

class NaturalPersonRole(BaseDataClass):
    """
    A class to specify the role(s) that natural person(s) may have in relation to the contract.
    """
    personReference: AttributeWithReference | NaturalPerson = Field(..., description="A reference to the natural person to whom the role refers to.")
    """
          A reference to the natural person to whom the role refers to.
    """
    role: Optional[List[AttributeWithMeta[NaturalPersonRoleEnum] | NaturalPersonRoleEnum]] = Field(None, description="FpML specifies a person role that is distinct from the party role.")
    """
          FpML specifies a person role that is distinct from the party role.
    """

from cdm.base.staticdata.party.NaturalPerson import NaturalPerson

NaturalPersonRole.update_forward_refs()
