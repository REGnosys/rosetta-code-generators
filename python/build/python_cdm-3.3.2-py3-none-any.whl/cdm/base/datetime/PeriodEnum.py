from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['PeriodEnum']

from enum import Enum

class PeriodEnum(Enum):
    """
    The enumerated values to specify the period, e.g. day, week.
    """
    D = "D"
    """
    Day
    """
    M = "M"
    """
    Month
    """
    W = "W"
    """
    Week
    """
    Y = "Y"
    """
    Year
    """
