from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['DayOfWeekEnum']

from enum import Enum

class DayOfWeekEnum(Enum):
    """
    The enumerated values to specify a day of the seven-day week.
    """
    FRI = "FRI"
    """
    Friday
    """
    MON = "MON"
    """
    Monday
    """
    SAT = "SAT"
    """
    Saturday
    """
    SUN = "SUN"
    """
    Sunday
    """
    THU = "THU"
    """
    Thursday
    """
    TUE = "TUE"
    """
    Tuesday
    """
    WED = "WED"
    """
    Wednesday
    """
