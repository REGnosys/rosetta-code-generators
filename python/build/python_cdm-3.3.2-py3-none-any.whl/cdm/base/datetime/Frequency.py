from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['Frequency']

from cdm.base.datetime.PeriodExtendedEnum import PeriodExtendedEnum

class Frequency(BaseDataClass):
    """
    A class for defining a date frequency, e.g. one day, three months, through the combination of an integer value and a standardized period value that is specified as part of an enumeration.
    """
    period: PeriodExtendedEnum = Field(..., description="A time period, e.g. a day, week, month, year or term of the stream.")
    """
          A time period, e.g. a day, week, month, year or term of the stream.
    """
    periodMultiplier: int = Field(..., description="A time period multiplier, e.g. 1, 2, or 3. If the period value is T (Term) then period multiplier must contain the value 1.")
    """
          A time period multiplier, e.g. 1, 2, or 3. If the period value is T (Term) then period multiplier must contain the value 1.
    """

    @cdm_condition
    def condition_0_TermPeriod(self):
        """
        FpML specifies that if period value is T (Term) then periodMultiplier must contain the value 1.
        """
        return if_cond(all_elements(self.period, "=", PeriodExtendedEnum.T), 'all_elements(self.periodMultiplier, "=", 1)', 'True', self)

    @cdm_condition
    def condition_1_PositivePeriodMultiplier(self):
        """
        FpML specifies periodMultiplier as a positive integer.
        """
        return all_elements(self.periodMultiplier, ">", 0)

from cdm.base.datetime.PeriodExtendedEnum import PeriodExtendedEnum

Frequency.update_forward_refs()
