from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['DateTimeList']


class DateTimeList(BaseDataClass):
    """
    List of dateTimes.
    """
    dateTime: List[datetime] = Field(None, description="The CDM specifies that the zoned date time is to be expressed in accordance with ISO 8601, either as UTC as an offset to UTC.")
    """
          The CDM specifies that the zoned date time is to be expressed in accordance with ISO 8601, either as UTC as an offset to UTC.
    """
    @cdm_condition
    def cardinality_dateTime(self):
        return check_cardinality(self.dateTime, 1, None)



DateTimeList.update_forward_refs()
