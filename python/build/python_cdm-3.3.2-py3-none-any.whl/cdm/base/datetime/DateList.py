from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['DateList']


class DateList(BaseDataClass):
    """
    List of dates.
    """
    date: List[date] = Field(None, description="")
    @cdm_condition
    def cardinality_date(self):
        return check_cardinality(self.date, 1, None)



DateList.update_forward_refs()
