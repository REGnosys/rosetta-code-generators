from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['InterpolationMethodEnum']

from enum import Enum

class InterpolationMethodEnum(Enum):
    """
    The enumerated values to specify the interpolation method, e.g. linear.
    """
    LINEAR = "LINEAR"
    """
    Linear Interpolation applicable.
    """
    LINEAR_ZERO_YIELD = "LINEAR_ZERO_YIELD"
    """
    Linear Interpolation applicable.
    """
    NONE = "NONE"
    """
    No Interpolation applicable.
    """
