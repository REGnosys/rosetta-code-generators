from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['MultipleCreditNotations']

from cdm.base.math.QuantifierEnum import QuantifierEnum
from cdm.observable.asset.CreditNotationMismatchResolutionEnum import CreditNotationMismatchResolutionEnum
from cdm.observable.asset.CreditRatingAgencyEnum import CreditRatingAgencyEnum

class MultipleCreditNotations(BaseDataClass):
    """
    Represetns a class to specify multiple credit notations alongside a conditional 'any' or 'all' qualifier.
    """
    condition: QuantifierEnum = Field(..., description="An enumerated element, to qualify whether All or Any credit notation applies.")
    """
          An enumerated element, to qualify whether All or Any credit notation applies.
    """
    creditNotation: List[AttributeWithMeta[CreditNotation] | CreditNotation] = Field(None, description="At least two credit notations much be specified.")
    """
          At least two credit notations much be specified.
    """
    @cdm_condition
    def cardinality_creditNotation(self):
        return check_cardinality(self.creditNotation, 2, None)

    mismatchResolution: Optional[CreditNotationMismatchResolutionEnum] = Field(None, description="")
    referenceAgency: Optional[CreditRatingAgencyEnum] = Field(None, description="")

    @cdm_condition
    def condition_0_ReferenceAgency(self):
        """
        If the mismatch resolution is ReferenceAgency, ensure that the reference agency is specified.
        """
        return if_cond(all_elements(MultipleCreditNotations.mismatchResolution, "=", CreditNotationMismatchResolutionEnum.ReferenceAgency), '((MultipleCreditNotations.referenceAgency) is not None)', 'True', self)

from cdm.observable.asset.CreditNotation import CreditNotation
from cdm.observable.asset.MultipleCreditNotations import MultipleCreditNotations
from cdm.observable.asset.CreditNotationMismatchResolutionEnum import CreditNotationMismatchResolutionEnum

MultipleCreditNotations.update_forward_refs()
