from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['Money']

from cdm.base.math.Quantity import Quantity

class Money(Quantity):
    """
    Defines a monetary amount in a specified currency.
    """

    @cdm_condition
    def condition_0_CurrencyUnitExists(self):
        return ((self.unit.currency) is not None)


Money.update_forward_refs()
