from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['FloatingRateOption']

from cdm.base.staticdata.asset.rates.FloatingRateIndexEnum import FloatingRateIndexEnum
from cdm.base.staticdata.asset.rates.InflationRateIndexEnum import InflationRateIndexEnum

class FloatingRateOption(BaseDataClass):
    """
    Specification of a floating rate option as a floating rate index and tenor.
    """
    floatingRateIndex: Optional[AttributeWithMeta[FloatingRateIndexEnum] | FloatingRateIndexEnum] = Field(None, description="The reference index that is used to specify the floating interest rate. The FpML standard maintains the list of such indices, which are positioned as enumeration values as part of the CDM.")
    """
          The reference index that is used to specify the floating interest rate. The FpML standard maintains the list of such indices, which are positioned as enumeration values as part of the CDM.
    """
    indexTenor: Optional[Period] = Field(None, description="The ISDA Designated Maturity, i.e. the floating rate tenor.")
    """
          The ISDA Designated Maturity, i.e. the floating rate tenor.
    """
    inflationRateIndex: Optional[AttributeWithMeta[InflationRateIndexEnum] | InflationRateIndexEnum] = Field(None, description="The reference index that is used to specify the inflation interest rate. The FpML standard maintains the list of such indices, which are positioned as enumeration values as part of the CDM.")
    """
          The reference index that is used to specify the inflation interest rate. The FpML standard maintains the list of such indices, which are positioned as enumeration values as part of the CDM.
    """

    @cdm_condition
    def condition_0_FloatingRateIndex(self):
        """
        A required choice condition for either a floating rate or inflation rate index.
        """
        return self.check_one_of_constraint('floatingRateIndex', 'inflationRateIndex', necessity=True)

from cdm.base.datetime.Period import Period

FloatingRateOption.update_forward_refs()
