from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['OptionReferenceTypeEnum']

from enum import Enum

class OptionReferenceTypeEnum(Enum):
    """
    The enumeration values to specify the reference source that determines the final settlement price of the option.
    """
    FUTURE = "FUTURE"
    """
    Reference from the price of a future contract.
    """
    SPOT = "SPOT"
    """
    Reference from an underlyer spot price.
    """
