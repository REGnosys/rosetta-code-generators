from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CrossRate']

from cdm.observable.asset.QuotedCurrencyPair import QuotedCurrencyPair

class CrossRate(QuotedCurrencyPair):
    """
    A class that is used for including the currency exchange rates used to cross between the traded currencies for non-base currency FX contracts.
    """
    forwardPoints: Optional[float] = Field(None, description="An optional element used for deals consummated in the FX Forwards market. Forward points represent the interest rate differential between the two currencies traded and are quoted as a premium or a discount. Forward points are added to, or subtracted from, the spot rate to create the rate of the forward trade.")
    """
          An optional element used for deals consummated in the FX Forwards market. Forward points represent the interest rate differential between the two currencies traded and are quoted as a premium or a discount. Forward points are added to, or subtracted from, the spot rate to create the rate of the forward trade.
    """
    rate: float = Field(..., description="The exchange rate used to cross between the traded currencies.")
    """
          The exchange rate used to cross between the traded currencies.
    """
    spotRate: Optional[float] = Field(None, description="An optional element used for FX forwards and certain types of FX OTC options. For deals consummated in the FX Forwards Market, this represents the current market rate for a particular currency pair.")
    """
          An optional element used for FX forwards and certain types of FX OTC options. For deals consummated in the FX Forwards Market, this represents the current market rate for a particular currency pair.
    """

    @cdm_condition
    def condition_0_CrossRate(self):
        return if_cond(((self.forwardPoints) is not None), '((self.spotRate) is not None)', 'True', self)


CrossRate.update_forward_refs()
