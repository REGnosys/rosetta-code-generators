from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['CreditNotationBoundaryEnum']

from enum import Enum

class CreditNotationBoundaryEnum(Enum):
    """
    Identifies an agency rating as a simple scale boundary of minimum or maximum.
    """
    MAXIMUM = "MAXIMUM"
    """
    Denotes a maxiumum boundary
    """
    MINIMUM = "MINIMUM"
    """
    Denotes a minumum boundary
    """
