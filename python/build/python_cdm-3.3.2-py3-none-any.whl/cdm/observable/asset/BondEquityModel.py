from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['BondEquityModel']


class BondEquityModel(BaseDataClass):
    """
     Bond equity model to value convertible bonds and modelled onto BondEquity.model in FpML.
    """
    bondchoiceModel: Optional[BondChoiceModel] = Field(None, description="Either the bond or convertible bond.")
    """
          Either the bond or convertible bond.
    """
    equity: Optional[Equity] = Field(None, description="The equity.")
    """
          The equity.
    """

    @cdm_condition
    def condition_0_(self):
        return self.check_one_of_constraint('bondchoiceModel', 'equity', necessity=True)

from cdm.observable.asset.BondChoiceModel import BondChoiceModel
from cdm.base.staticdata.asset.common.Equity import Equity

BondEquityModel.update_forward_refs()
