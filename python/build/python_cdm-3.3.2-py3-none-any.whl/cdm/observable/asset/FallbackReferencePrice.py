from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from pydantic import Field
from cdm.utils import *

__all__ = ['FallbackReferencePrice']

from cdm.observable.asset.SettlementRateOptionEnum import SettlementRateOptionEnum

class FallbackReferencePrice(BaseDataClass):
    """
    The method, prioritised by the order it is listed in this element, to get a replacement rate for the disrupted settlement rate option.
    """
    calculationAgentDetermination: Optional[CalculationAgent] = Field(None, description="The calculation agent will decide the rate.")
    """
          The calculation agent will decide the rate.
    """
    fallBackSettlementRateOption: Optional[List[AttributeWithMeta[SettlementRateOptionEnum] | SettlementRateOptionEnum]] = Field(None, description="This settlement rate option will be used in its place.")
    """
          This settlement rate option will be used in its place.
    """
    fallbackSurveyValuationPostponement: Optional[bool] = Field(None, description="Request rate quotes from the market. This element is set as type Empty in FpML. When present, the FpML synonym is mapped to a value True in the CDM.")
    """
          Request rate quotes from the market. This element is set as type Empty in FpML. When present, the FpML synonym is mapped to a value True in the CDM.
    """
    valuationPostponement: Optional[ValuationPostponement] = Field(None, description="Specifies how long to wait to get a quote from a settlement rate option upon a price source disruption.")
    """
          Specifies how long to wait to get a quote from a settlement rate option upon a price source disruption.
    """

    @cdm_condition
    def condition_0_MaximumDaysOfPostponement(self):
        """
        FpML specifies maximumDaysOfPostponement as a positive integer.
        """
        return if_cond(((self.valuationPostponement) is not None), 'all_elements(self.valuationPostponement.maximumDaysOfPostponement, ">", 0)', 'True', self)

    @cdm_condition
    def condition_1_FallbackCalculationAgent(self):
        return if_cond(((self.calculationAgentDetermination.calculationAgentParty) is not None), 'all_elements(self.calculationAgentDetermination.calculationAgentParty, "=", AncillaryRoleEnum.CalculationAgentFallback)', 'True', self)

from cdm.observable.asset.CalculationAgent import CalculationAgent
from cdm.observable.asset.ValuationPostponement import ValuationPostponement
from cdm.base.staticdata.party.AncillaryRoleEnum import AncillaryRoleEnum

FallbackReferencePrice.update_forward_refs()
